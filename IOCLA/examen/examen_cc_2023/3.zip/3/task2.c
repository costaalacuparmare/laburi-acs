#include <limits.h>
#include <stdio.h>

// TODO: Freestyle starts here
int task2(int a, int b, int *sum)
{
    if (a > INT_MAX-b)
        sum = 0;
    else
        sum = a + b;
    return sum;
}
