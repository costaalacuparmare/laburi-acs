#include <stdio.h>

void task3()
{
    // TODO: Call secret function with correct arguments
    secret(0, 10000);
}

int main(void)
{
    int sum = 0;
    int overflow = task2(1 << 30, 1 << 30, &sum);
    printf("%d %d\n", overflow, sum);
    task3();
}
