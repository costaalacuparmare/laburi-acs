#include <stdio.h>
#include <stdlib.h>

#define CHECKER_BIT_INDEX 7
#define KEY 0b11010011

// TODO: freestyle starts here, implement Task 2
void task2(void *encrypted_data, int size) {

}
