# Data Structures & Algorithms - 3rd Homework

### Constantinescu Vlad 314CB

The archive contains the implementation of the two tasks required 

Punctaj local: 75/100 iupi

## Implementation
     
    I read the input using the two I/O functions and did blabla with the graph

#### I/O functions

- `openIn` bla bla bla pt input


- `openOut` bla bla bla pt output

#### Vertices functions
- `InitV`

## Task 1

    I wanted to make this awsome so this is me trying

- `double_edges` bla bla bla


- `DFS` bla bla bla


- `getZones`


- `PushListPrim`


- `PopListPrim` 


- `PopFirstEdge`


- `cmp`


- `lazy_prim`


- `task1`

## Task 2

haha