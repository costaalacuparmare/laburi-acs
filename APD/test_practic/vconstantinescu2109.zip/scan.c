#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define MAX_N 100
int N, P;
pthread_barrier_t barrier;

typedef struct {
    int id;
    int partial_sums[MAX_N];
    pthread_mutex_t mutex;
    pthread_barrier_t barrier;
    int v[MAX_N];
} scan_args;

void *scan(void *args) {
    scan_args *info = (scan_args *) args;

    // paralel
    int start = info->id * N / P;
    int end = (info->id + 1) * N / P;
    if (info->id == P - 1) {
        end = N;
    }

    printf("Thread %d: start %d, end %d\n", info->id, start, end);

    int first = 0;

    int local_sums[N];
    if (start == 0) {
        local_sums[0] = info->v[0];
        first = 1;
    } else {
        // wait previous thread to finish partial (but it waits infinite so mutexes must be arranged)
        while (1) {
            pthread_mutex_lock(&info->mutex);
            if (info->partial_sums[start - 1] != -1) {
                local_sums[start - 1] = info->partial_sums[start - 1];
                pthread_mutex_unlock(&info->mutex);
                break;
            }
            pthread_mutex_unlock(&info->mutex);
        }
    }
    // make partial
    for (int i = start; i < end; i++) {
        if (first == 1) {
            first = 0;
            continue;
        }
        local_sums[i] = local_sums[i - 1] + info->v[i];
    }

    // add to global results
    pthread_mutex_lock(&info->mutex);
    for (int i = start; i < end; i++) {
        info->partial_sums[i] = local_sums[i];
    }
    pthread_mutex_unlock(&info->mutex);

    // wait all threads to finish before printing
    pthread_barrier_wait(&barrier);

    if (info->id == P - 1) {
        printf("Partial sums: ");
        for (int i = 0; i < N; i++) {
            printf("%d ", info->partial_sums[i]);
        }
        printf("\n");
    }

    return NULL;
}

int main(int argc, char **argv) {
    N = atoi(argv[1]);
    P = atoi(argv[2]);
    printf("P : %d\n", P);
    scan_args args[P];
    int v[N];
    for (int i = 0; i < N; i++) {
        v[i] = atoi(argv[i + 3]);
    }
    pthread_mutex_t mutex;
    pthread_mutex_init(&mutex, NULL);
    pthread_barrier_init(&barrier, NULL, P);
    pthread_t threads[P];

    for (int i = 0; i < P; i++) {
        args[i].id = i;
        for (int j = 0; j < N; j++) {
            args[i].v[j] = v[j];
        }
        args[i].mutex = mutex;
        args[i].barrier = barrier;
        for (int j = 0; j < MAX_N; j++) {
            args[i].partial_sums[j] = -1;
        }
        int r = pthread_create(&threads[i], NULL, scan, &args[i]);
        if (r) {
            printf("Error %d\n", i);
            exit(-1);
        }
    }

    for (int i = 0; i < P; i++) {
        pthread_join(threads[i], NULL);
    }

    pthread_mutex_destroy(&mutex);
    pthread_barrier_destroy(&barrier);
    return 0;
}