Proiect realizat de Constantinescu Vlad si Popescu Matei
La laboratorul de miercuri 17.01.2023 ne-ati spus ca trebuie sa implementam cu rising_clock si v-am intrebat ce altceva
ar trebui facut pentru nota de 8 (momentan ne-ati dat 6) si acesta e singurul lucru pe care ni l-ati zis pentru ca a trebuit sa prezentam
penultimii. Credeti ca ati putea sa va uitati pana vineri in ziua deadline-ului si sa ne spuneti ce alte posibile modificari ar trebui
facute. Va multumim frumos si o zi frumoasa!