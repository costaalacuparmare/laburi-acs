#define DIVIZOR1 7
#define DIVIZOR2 11
