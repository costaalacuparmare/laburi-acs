#pragma once

#include "components/simple_scene.h"
#include <vector>
#include <iostream>
#include "lab_m1/lab5/lab_camera.h"
#include "lab_m1/lab4/transform3D.h"

namespace tema2
{
    class Obstacle
    {
    public:
        glm::vec3 position;
        float radius;
        float rotationY;
        float scale;
        Mesh *mesh;
        int checkStatus = 0;

        void generateTreeMesh();
        void generateBuildingMesh();
        void generateCheckpointMesh();

    };

    class Drone
    {
    public:
        float global_scale = 300.0f;

        // Mesh variables
        Mesh *droneMesh, *rotorMesh, *arrowMesh;

        // Drone position variables
        glm::vec3 position = glm::vec3(0, 1.0f, 0);
        std::vector<glm::vec3> rotorPositions{};
        float radius;
        int size;

        // Drone movement variables
        float rotationAngle = 0.0f;
        float rotorAngle = 0.0f;
        float pitchAngle = 0.0f;
        float rollAngle = 0.0f;
        glm::mat4 orientation = glm::mat4(1);
        int moveMode = 0;
        bool collision = false;
        glm::vec3 knockbackForce = glm::vec3(0);
        float knockbackTimer{};
        glm::vec3 lastMovementDirection = glm::vec3(0);
        bool inKnockback = false;
        float pitchVelocity = 0.0f;
        float rollVelocity = 0.0f;
        float yawVelocity = 0.0f;
        float thrust = 0.0f;

        // Game logic variables
        std::vector<Obstacle> checkpoints{};
        int gatesPassed = 0;
        bool stopTime{};

        explicit Drone(int size);

        // Mesh generation functions and variables
        void generateDroneMesh(glm::vec3 bodyColor);
        void generateRotorMesh() const;
        void generateArrow(glm::vec3 color) const;
        void generateRotorPositions();

        // Render functions and variables
        glm::mat4 RenderArrow() const;
        glm::mat4 RenderDrone() const;
        glm::mat4 RenderRotor(float deltaTimeSeconds, glm::vec3 rotorPosition);

        // Movement functions
        void SimpleMode(float deltaTime, WindowObject *window, float droneSpeed, int drone_type);
        void AcroMode(float deltaTime, WindowObject *window, float droneSpeed, int drone_type);
        void AngleMode(float deltaTime, WindowObject *window, float droneSpeed, int drone_type);
    };

    class Tema2 : public gfxc::SimpleScene
    {
    public:
        void Init() override;

    private:
        void FrameStart() override;
        void Update(float deltaTimeSeconds) override;
        void FrameEnd() override;
        void OnInputUpdate(float deltaTime, int mods) override;
        void OnKeyPress(int key, int mods) override;
        void OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY) override;
        void OnMouseBtnPress(int mouseX, int mouseY, int button, int mods) override;

        // Functions to render the scene
        void RenderMesh(Mesh *mesh, Shader *shader, const glm::mat4 &modelMatrix, implemented::Camera *camera);
        void RenderEnvironment(Drone *drone, implemented::Camera *camera, float deltaTime);
        void RenderDrone(Drone *drone, float deltaTimeSeconds, implemented::Camera *camera);
        void RenderDronePerspective(implemented::Camera* camera, float deltaTimeSeconds,
                                           glm::ivec2 viewportPosition, glm::ivec2 viewportSize);
        void RenderTime(Drone *drone, implemented::Camera *camera);

        // Functions for collision detection
        void CheckCollisions(float global_scale, Drone *drone, Drone *drone2);

    protected:

        // camera variables
        float fovY, zNear, zFar;
        implemented::Camera *firstCamera, *secondCamera;
        glm::mat4 projectionMatrix;

        // scene mesh variables
        Mesh *terrainMesh, *timerIntMesh, *timerExtMesh, *cloudMesh;
        std::vector<Obstacle> obstacles{};
        int treeCount = 100;
        int buildingCount = 30;
        int checkpointCount = 5;
        int cloudCount = 30;
        Drone *drone1, *drone2;
        float cloudMovement = 0.0f;
        bool cloudDirection = false;

        // game logic variables
        int playerCount = 1;
        float elapsedTime = 15.0f;
        bool timeFinished = false;
    };

    void CreateMesh(Mesh *targetMesh, const std::vector<VertexFormat> &vertices, const std::vector<unsigned int> &indices);
    void generateObstaclePositions(int treeCount, int buildingCount, int checkpointCount, std::vector<Obstacle> &obstacles);
    Mesh *generateTerrainMesh();
    Mesh *generateCloud(float radius, glm::vec3 color);
    Mesh *generateTimerInt(float time, float height);
    Mesh *generateTimerExt(float time, float height);
}