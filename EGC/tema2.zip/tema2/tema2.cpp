#include "lab_m1/tema2/tema2.h"

using namespace std;
using namespace tema2;

bool CheckSphereCollision(glm::vec3 pos1, float radius1, glm::vec3 pos2, float radius2) {
    return glm::distance(pos1, pos2) < (radius1 + radius2);
}

bool CheckCylinderCollision(glm::vec3 pos1, float radius1, float height1,
                            glm::vec3 pos2, float radius2, float height2) {
    float horizontalDist = glm::distance(glm::vec2(pos1.x, pos1.z), glm::vec2(pos2.x, pos2.z));
    bool horizontalOverlap = horizontalDist < (radius1 + radius2);
    bool verticalOverlap = abs(pos1.y - pos2.y) < (height1 / 2.0f + height2 / 2.0f);
    return horizontalOverlap && verticalOverlap;
}

bool CheckAABB(glm::vec3 min1, glm::vec3 max1, glm::vec3 min2, glm::vec3 max2) {
    return (min1.x <= max2.x && max1.x >= min2.x) &&
           (min1.y <= max2.y && max1.y >= min2.y) &&
           (min1.z <= max2.z && max1.z >= min2.z);
}

void Tema2::CheckCollisions(float global_scale, Drone *drone, Drone *otherDrone) {
    drone->collision = false;
    // Check trees
    for (int i = 0; i < treeCount; ++i) {
        glm::vec3 treePos = obstacles[i].position;
        float treeTrunkRadius = global_scale * 0.002f;
        float treeTrunkHeight = global_scale * 0.04f;
        float treeCrownRadius = global_scale * 0.01f;

        // Check trunk
        if (CheckCylinderCollision(drone->position, drone->radius + 1.0f, drone->radius * 2.0f,
                                   treePos, treeTrunkRadius, treeTrunkHeight)) {
            drone->collision = true;
            break;
        }

        // Check crown 1
        if (CheckSphereCollision(drone->position, drone->radius,
                                 treePos + glm::vec3(0, treeTrunkHeight * 0.61f, 0), treeCrownRadius)) {
            drone->collision = true;
            break;
        }

        // Check crown 2
        if (CheckSphereCollision(drone->position, drone->radius,
                                 treePos + glm::vec3(0, treeTrunkHeight * 0.61f + treeCrownRadius, 0), treeCrownRadius)) {
            drone->collision = true;
            break;
        }
    }

    // Check buildings
    for (int i = 0; i < buildingCount; ++i) {
        glm::vec3 buildingPos = obstacles[i + treeCount].position;
        glm::vec3 buildingMin = buildingPos - glm::vec3(global_scale * 0.03f, global_scale * 0.01f, global_scale * 0.03f);
        glm::vec3 buildingMax = buildingPos + glm::vec3(global_scale * 0.03f, global_scale * 0.035f, global_scale * 0.03f);

        if (CheckAABB(drone->position - glm::vec3(drone->radius),
                      drone->position + glm::vec3(drone->radius), buildingMin, buildingMax)) {
            cout << "Building collision" << endl;
            drone->collision = true;
            break;
        }
    }

    // Check collision with ground
    if (drone->position.y < 0.7f) {
        drone->collision = true;
    }

    // Check collision with world edge
    if (drone->position.x < -175.5f || drone->position.x > 175.5f || drone->position.z < -175.5f || drone->position.z > 175.5f) {
        drone->collision = true;
    }

    // Check collision between drones
    if (CheckSphereCollision(drone->position, drone->radius + 1.3f, otherDrone->position, otherDrone->radius + 1.3f)) {
        drone->collision = true;
    }


    // Check collision with checkpoints
    for (int i = 0; i < checkpointCount; ++i) {
        Obstacle checkpoint = drone->checkpoints[i];

        float gateBaseSize = global_scale * 0.013f;
        float gateHeight = gateBaseSize * checkpoint.scale;
        glm::vec3 checkpointPos = checkpoint.position;
        float verticalOffset = gateHeight * 1.5f;
        checkpointPos.y += verticalOffset;

        glm::vec3 scaledBaseSize = glm::vec3(gateBaseSize / 2 * checkpoint.scale, gateBaseSize / 2 * checkpoint.scale, 0);

        vector<glm::vec3> corners = {
                glm::vec3(-scaledBaseSize.x, -scaledBaseSize.y, 0),  // Bottom-left
                glm::vec3(scaledBaseSize.x, -scaledBaseSize.y, 0),   // Bottom-right
                glm::vec3(scaledBaseSize.x, scaledBaseSize.y, 0),    // Top-right
                glm::vec3(-scaledBaseSize.x, scaledBaseSize.y, 0)    // Top-left
        };

        glm::mat4 rotationMatrix = transform3D::RotateOY(RADIANS(checkpoint.rotationY));

        // Rotate and translate the corners
        for (auto& corner : corners) {
            glm::vec4 rotatedCorner = rotationMatrix * glm::vec4(corner, 1.0f);
            corner = checkpointPos + glm::vec3(rotatedCorner) + glm::vec3(0, verticalOffset, 0);
        }

        glm::vec3 checkpointMin = corners[0];
        glm::vec3 checkpointMax = corners[0];

        for (const auto& corner : corners) {
            checkpointMin = glm::min(checkpointMin, corner);
            checkpointMax = glm::max(checkpointMax, corner);
        }

        // Check collision with the square
        if (CheckAABB(drone->position - glm::vec3(drone->radius + 0.4f),
                      drone->position + glm::vec3(drone->radius + 0.4f), checkpointMin, checkpointMax)) {

            if (checkpoint.checkStatus == 0) {
                drone->collision = true;
            } else if (checkpoint.checkStatus == 1) {
                glm::vec3 gateForward = glm::normalize(glm::vec3(
                        sin(RADIANS(checkpoint.rotationY)),
                        0,
                        cos(RADIANS(checkpoint.rotationY))
                ));

                // Calculate the drone-to-gate vector
                glm::vec3 droneToGate = glm::normalize(
                        checkpointPos - drone->position);

                // Dot product to determine the side
                float dot = glm::dot(gateForward, droneToGate);

                if (dot > 0) {
                    drone->checkpoints[i].checkStatus = 2;
                    drone->gatesPassed++;
                    drone->checkpoints[i].generateCheckpointMesh();
                    if (i < checkpointCount - 1) {
                        drone->checkpoints[i + 1].checkStatus = 1;
                        drone->checkpoints[i + 1].generateCheckpointMesh();
                    }
                } else {
                    drone->collision = true;
                }
            }
        }
    }
}

void Tema2::Init() {
    // Init custom shader
    auto *shader = new Shader("TerrainShader");
    shader->AddShader(PATH_JOIN(window->props.selfDir, SOURCE_PATH::M1, "tema2",
                                "shaders", "VertexShader.glsl"),
                      GL_VERTEX_SHADER);
    shader->AddShader(PATH_JOIN(window->props.selfDir, SOURCE_PATH::M1, "tema2",
                                "shaders", "FragmentShader.glsl"),
                      GL_FRAGMENT_SHADER);
    shader->CreateAndLink();
    shaders[shader->GetName()] = shader;

    // Generate terrain
    terrainMesh = generateTerrainMesh();

    // Add drones to the list of obstacles to avoid collisions
    auto *droneObstacle = new Obstacle();
    droneObstacle->position = glm::vec3(0, 1.0f, 0);
    droneObstacle->radius = 5.0f;
    obstacles.push_back(*droneObstacle);

    generateObstaclePositions(treeCount, buildingCount, checkpointCount, obstacles);

    // Remove the drone from the list of obstacles
    for (int i = 0; i < obstacles.size(); ++i) {
        if (obstacles[i].position == glm::vec3(0, 1.0f, 0)) {
            obstacles.erase(obstacles.begin() + i);
            break;
        }
    }

    // Create the first player
    drone1 = new Drone(1);
    drone1->generateDroneMesh(glm::vec3(1.0f, 0.0f, 0.0f));
    drone1->generateRotorMesh();
    drone1-> position = glm::vec3(-2.0f, 4.0f, 0.0f);
    drone1->generateArrow(glm::vec3(1.0f, 0.0f, 0.0f));
    firstCamera = new implemented::Camera();

    // Create the second player
    drone2 = new Drone(2);
    drone2->generateDroneMesh(glm::vec3(0.0f, 0.0f, 1.0f));
    drone2->generateRotorMesh();
    drone2->position = glm::vec3(2.0f, 4.0f, 0.0f);
    drone2->generateArrow(glm::vec3(0.0f, 0.0f, 1.0f));
    secondCamera = new implemented::Camera();

    // Add checkpoints to the drones
    for (int i = 0; i < checkpointCount; i++) {
        Obstacle checkpoint = obstacles[i + treeCount + buildingCount];
        drone1->checkpoints.push_back(checkpoint);
        drone2->checkpoints.push_back(checkpoint);
    }

    // Create the cloud obstacles
    cloudMesh = generateCloud(35.0f, glm::vec3(1.0f, 1.0f, 1.0f));
    for (int i = 0; i < cloudCount; ++i) {
        float randomX = ((rand() % 500) - 170);
        float randomZ = ((rand() % 500) - 170);

        glm::vec3 cloudPos = glm::vec3(randomX, 45.0f, randomZ);
        auto *cloudObstacle = new Obstacle();
        cloudObstacle->position = cloudPos;
        cloudObstacle->radius = 35.0f;
        obstacles.push_back(*cloudObstacle);
    }

    // Timer
    timerIntMesh = generateTimerInt(elapsedTime, 1.0f);
    timerExtMesh = generateTimerExt(elapsedTime, 1.0f);

    // Camera settings
    fovY = RADIANS(60);
    zNear = 0.01f;
    zFar = 300.0f;
    projectionMatrix = glm::perspective(fovY, window->props.aspectRatio, zNear, zFar);
}


void Tema2::FrameStart() {
    // Clears the color buffer (using the previously set color) and depth buffer
    glClearColor(0, 0.776f, 0.82f, 1);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

}

void Tema2::Update(float deltaTimeSeconds) {
    glm::ivec2 resolution = window->GetResolution();

    // Player modes
    if (playerCount == 1) {
        RenderDronePerspective(firstCamera, deltaTimeSeconds, glm::ivec2(0, 0), resolution);
    } else {
        RenderDronePerspective(firstCamera, deltaTimeSeconds, glm::ivec2(0, 0), glm::ivec2(resolution.x / 2, resolution.y));
        RenderDronePerspective(secondCamera, deltaTimeSeconds, glm::ivec2(resolution.x / 2, 0), glm::ivec2(resolution.x / 2, resolution.y));
    }
}

void Tema2::RenderDronePerspective(implemented::Camera* camera, float deltaTimeSeconds,
                                   glm::ivec2 viewportPosition, glm::ivec2 viewportSize) {
    Drone* drone;
    Drone* otherDrone;
    if (camera == firstCamera) {
        drone = drone1;
        otherDrone = drone2;
    } else {
        drone = drone2;
        otherDrone = drone1;
    }

    if (elapsedTime != 0) {
        RenderTime(drone, camera);
    }

    if (playerCount == 1) {
        otherDrone->position = glm::vec3(0, -100, 0);
    }

    glViewport(viewportPosition.x, viewportPosition.y, viewportSize.x, viewportSize.y);

    // Compute camera position and orientation relative to the drone
    glm::vec3 dronePosition = drone->position;
    glm::vec3 cameraOffset = glm::vec3(0.0f, 3.0f, 8.0f);
    glm::mat4 rotationMatrix = transform3D::RotateOY(RADIANS(drone->rotationAngle));
    glm::vec3 cameraPosition = dronePosition + glm::vec3(rotationMatrix * glm::vec4(cameraOffset, 1.0f));
    camera->Set(cameraPosition, dronePosition, glm::vec3(0.0f, 1.0f, 0.0f));

    // Render terrain
    glm::mat4 modelMatrix = glm::mat4(1);
    RenderMesh(terrainMesh, shaders["TerrainShader"], modelMatrix, camera);

    // Render environment and drones
    RenderEnvironment(drone, camera, deltaTimeSeconds);
    RenderDrone(drone, deltaTimeSeconds, camera);
    RenderDrone(otherDrone, deltaTimeSeconds, camera);

    // Check for collisions
    CheckCollisions(300.0f, drone, otherDrone);
}



void Tema2::RenderEnvironment(Drone *drone, implemented::Camera *camera, float deltaTime) {
    for (int i = 0; i < treeCount; ++i) {
        glm::vec3 pos = obstacles[i].position;
        Mesh *treeMesh = obstacles[i].mesh;
        glm::mat4 modelMatrix = transform3D::Translate(pos.x, pos.y, pos.z);
        RenderMesh(treeMesh, shaders["VertexColor"], modelMatrix, camera);
    }

    for (int i = 0; i < buildingCount; ++i) {
        glm::vec3 pos = obstacles[i + treeCount].position;
        Mesh *buildingMesh = obstacles[i + treeCount].mesh;
        glm::mat4 modelMatrix = transform3D::Translate(pos.x, pos.y, pos.z);
        RenderMesh(buildingMesh, shaders["VertexColor"], modelMatrix, camera);
    }

    for (int i = 0; i < cloudCount; ++i) {
        Obstacle cloud = obstacles[i + treeCount + buildingCount + checkpointCount];
        glm::mat4 modelMatrix = transform3D::Translate(cloud.position.x + cloudMovement,
                                                       45.0f, cloud.position.z);
        RenderMesh(cloudMesh, shaders["VertexColor"], modelMatrix, camera);
    }

    for (int i = 0; i < checkpointCount; ++i) {
        glm::vec3 pos = drone->checkpoints[i].position;
        glm::mat4 modelMatrix = transform3D::Translate(pos.x, pos.y, pos.z);

        float angle = drone->checkpoints[i].rotationY;
        modelMatrix *= transform3D::RotateOY(RADIANS(angle));

        float scale = drone->checkpoints[i].scale;
        modelMatrix *= transform3D::Scale(scale, scale, scale);

        Mesh *checkpointMesh = drone->checkpoints[i].mesh;
        RenderMesh(checkpointMesh, shaders["VertexColor"], modelMatrix, camera);
    }

    if (cloudMovement > 100.0f) {
        cloudDirection = true;
    } else if (cloudMovement < -100.0f) {
        cloudDirection = false;
    }

    if (cloudDirection) {
        cloudMovement -= deltaTime * 8.0f;
    } else {
        cloudMovement += deltaTime * 8.0f;
    }

}

void Tema2::RenderDrone(Drone *drone, float deltaTimeSeconds, implemented::Camera *camera) {
    glm::mat4 modelMatrix = drone->RenderDrone();
    RenderMesh(drone->droneMesh, shaders["VertexColor"], modelMatrix, camera);

    drone->generateRotorPositions();
    for (auto rotorPosition : drone->rotorPositions) {
        modelMatrix = drone->RenderRotor(deltaTimeSeconds, rotorPosition);
        RenderMesh(drone->rotorMesh, shaders["VertexColor"], modelMatrix, camera);
    }

    if (!drone->stopTime) {
        modelMatrix = drone->RenderArrow();
        RenderMesh(drone->arrowMesh, shaders["VertexColor"], modelMatrix,camera);
    }
}

void Tema2::RenderTime(Drone *drone, implemented::Camera *camera) {
    // Update the timer
    if (!drone->stopTime) {
        elapsedTime -= 0.001f;
    }

    // Update the timer meshes
    timerIntMesh = generateTimerInt(elapsedTime, 1.0f);

    if (elapsedTime > 0) {
    glm::mat4 modelMatrix = drone->RenderDrone();
    modelMatrix /= transform3D::RotateOY(RADIANS(45.0f));
    modelMatrix /= transform3D::RotateOZ(RADIANS(drone->rollAngle));
    modelMatrix /= transform3D::RotateOX(RADIANS(drone->pitchAngle));
    modelMatrix *= transform3D::Translate(-2.0f, 4.0f, -2.0f);
    modelMatrix *= transform3D::Scale(0.3f, 0.3f, 0.3f);
    RenderMesh(timerIntMesh, shaders["VertexColor"], modelMatrix, camera);
    RenderMesh(timerExtMesh, shaders["VertexColor"], modelMatrix, camera);
    } else {
        elapsedTime = 0;
        timeFinished = true;
    }
}

void Tema2::FrameEnd() {
    if (elapsedTime == 0 && timeFinished) {
        cout << "Players ran out of time!" << endl;
        cout << "Press R to restart the game." << endl;

        for (int i = 0; i < checkpointCount; i++) {
            drone1->checkpoints[i].checkStatus = 0;
            drone1->checkpoints[i].generateCheckpointMesh();
            drone2->checkpoints[i].checkStatus = 0;
            drone2->checkpoints[i].generateCheckpointMesh();
        }
        timeFinished = false;
    }

    if (drone1->gatesPassed == checkpointCount) {
        cout << "Player 1 wins!" << endl;
        cout << "Press R to restart the game." << endl;
        drone1->gatesPassed = 0;
        drone2->gatesPassed = 0;
        drone1->stopTime = true;
        drone2->stopTime = true;
        for (int i = 0; i < checkpointCount; i++) {
            drone2->checkpoints[i].checkStatus = 0;
            drone2->checkpoints[i].generateCheckpointMesh();
        }
    }

    if (drone2->gatesPassed == checkpointCount) {
        cout << "Player 2 wins!" << endl;
        cout << "Press R to restart the game." << endl;
        drone1->gatesPassed = 0;
        drone2->gatesPassed = 0;
        drone1->stopTime = true;
        drone2->stopTime = true;
        for (int i = 0; i < checkpointCount; i++) {
            drone1->checkpoints[i].checkStatus = 0;
            drone1->checkpoints[i].generateCheckpointMesh();
        }
    }

}

void Tema2::OnInputUpdate(float deltaTime, int mods) {
    float droneSpeed1 = 10.0f;
    float droneSpeed2 = 10.0f;

    if (window->KeyHold(GLFW_KEY_TAB)) droneSpeed1 *= 4.0f;
    if (window->KeyHold(GLFW_KEY_RIGHT_SHIFT)) droneSpeed2 *= 4.0f;

    if (drone1->moveMode == 0) {
        drone1->SimpleMode(deltaTime, window, droneSpeed1, 1);
    }
    if (drone1->moveMode == 1) {
        drone1->AngleMode(deltaTime, window, droneSpeed1, 1);
    }
    if (drone1->moveMode == 2) {
        drone1->AcroMode(deltaTime, window, droneSpeed1, 1);
    }
    if (drone2->moveMode == 0) {
        drone2->SimpleMode(deltaTime, window, droneSpeed2, 2);
    }
    if (drone2->moveMode == 1) {
        drone2->AngleMode(deltaTime, window, droneSpeed2, 2);
    }
    if (drone2->moveMode == 2) {
        drone2->AcroMode(deltaTime, window, droneSpeed2, 2);
    }
}

void Tema2::OnKeyPress(int key, int mods) {
    if (key == GLFW_KEY_V) {
        switch (drone1->moveMode) {
            case 0:
                drone1->moveMode = 1;
                break;
            case 1:
                drone1->moveMode = 2;
                break;
            default:
                drone1->moveMode = 0;
                break;
        }
    }

    if (key == GLFW_KEY_B) {
        switch (drone2->moveMode) {
            case 0:
                drone2->moveMode = 1;
                break;
            case 1:
                drone2->moveMode = 2;
                break;
            default:
                drone2->moveMode = 0;
                break;
        }
    }

    if (key == GLFW_KEY_P) {
        if (playerCount == 1) {
            elapsedTime = 15.0f;
            playerCount = 2;
            drone2->position = glm::vec3(2.0f, 4.0f, 0.0f);
        } else {
            elapsedTime = 15.0f;
            playerCount = 1;
        }
    }

    if (key == GLFW_KEY_R) {
        elapsedTime = 15.0f;
        drone1->position = glm::vec3(-2.0f, 4.0f, 0.0f);
        drone2->position = glm::vec3(2.0f, 4.0f, 0.0f);
        for (int i = 0; i < checkpointCount; i++) {
            drone1->checkpoints[i].checkStatus = 0;
            drone1->checkpoints[i].generateCheckpointMesh();
            drone2->checkpoints[i].checkStatus = 0;
            drone2->checkpoints[i].generateCheckpointMesh();
        }
        drone1->checkpoints[0].checkStatus = 1;
        drone1->checkpoints[0].generateCheckpointMesh();
        drone2->checkpoints[0].checkStatus = 1;
        drone2->checkpoints[0].generateCheckpointMesh();
        drone1->gatesPassed = 0;
        drone2->gatesPassed = 0;
        drone1->stopTime = false;
        drone2->stopTime = false;
    }
}

void Tema2::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY) {
    const float mouseSensitivity = 0.1f;
    const float maxPitch = 180.0f;

    drone1->pitchAngle = glm::clamp(drone1->pitchAngle + (float) deltaY * mouseSensitivity,
                                    -maxPitch, maxPitch);
    drone1->rotationAngle -= (float) deltaX * mouseSensitivity;
    drone1->rollAngle = glm::clamp(drone1->rollAngle - (float) deltaX * mouseSensitivity,
                                   -maxPitch, maxPitch);


    glm::mat4 yawRotation = transform3D::RotateOY(RADIANS(drone1->rotationAngle));
    glm::mat4 pitchRotation = transform3D::RotateOX(RADIANS(drone1->pitchAngle));
    glm::mat4 rollRotation = transform3D::RotateOZ(RADIANS(drone1->rollAngle));
    drone1->orientation = yawRotation * pitchRotation * rollRotation;
}


void Tema2::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods) {
    // press left mouse button to move the drone up
    if (button == 1) {
        drone1->thrust = 4.0f;
    }

    if (button == 2) {
        drone1->thrust = 5.0f;
    }

}
