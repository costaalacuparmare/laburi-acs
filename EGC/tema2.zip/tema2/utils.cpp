#include <set>
#include "tema2.h"

using namespace std;
using namespace tema2;

float global_scale = 300.0f;

void tema2::generateObstaclePositions(int treeCount, int buildingCount, int checkpointCount,
                                      vector<Obstacle>& obstacles) {
    srand(static_cast<unsigned int>(time(nullptr)));

    // Check overlap
    auto doesOverlap = [&](const glm::vec3& position, float radius) {
        for (const auto& obstacle : obstacles) {
            if (glm::distance(obstacle.position, position) < radius + obstacle.radius) {
                return true;
            }
        }
        return false;
    };

    // Generate positions for trees
    for (int i = 0; i < treeCount; ++i) {
        bool placed = false;
        for (int attempts = 0; attempts < 100 && !placed; ++attempts) {
            glm::vec3 position = glm::vec3(
                    (rand() / static_cast<float>(RAND_MAX)) * global_scale - global_scale / 2.0f,
                    0.0f,
                    (rand() / static_cast<float>(RAND_MAX)) * global_scale - global_scale / 2.0f
            );
            float treeRadius = global_scale * 0.01f; // Approximate tree size
            if (!doesOverlap(position, treeRadius)) {
                Obstacle tree;
                tree.position = position;
                tree.radius = treeRadius;
                tree.generateTreeMesh();
                obstacles.push_back(tree);
                placed = true;
            }
        }
    }

    // Generate positions for buildings
    for (int i = 0; i < buildingCount; ++i) {
        bool placed = false;
        for (int attempts = 0; attempts < 100 && !placed; ++attempts) {
            glm::vec3 position = glm::vec3(
                    (rand() / static_cast<float>(RAND_MAX)) * global_scale - global_scale / 2.0f,
                    0.0f,
                    (rand() / static_cast<float>(RAND_MAX)) * global_scale - global_scale / 2.0f
            );
            float buildingRadius = global_scale * 0.05f; // Approximate building size
            if (!doesOverlap(position, buildingRadius)) {
                Obstacle building;
                building.position = position;
                building.radius = buildingRadius;
                building.generateBuildingMesh();
                obstacles.push_back(building);
                placed = true;
            }
        }
    }

    // Generate positions for checkpoints
    for (int i = 0; i < checkpointCount; ++i) {
        bool placed = false;
        for (int attempts = 0; attempts < 100 && !placed; ++attempts) {
            glm::vec3 position = glm::vec3(
                    (rand() / static_cast<float>(RAND_MAX)) * global_scale - global_scale / 2.0f,0.0f,
                    (rand() / static_cast<float>(RAND_MAX)) * global_scale - global_scale / 2.0f
            );

            // Random size scaling for the checkpoint
            float scaleFactor = 0.7f + static_cast<float>(rand()) / static_cast<float>(RAND_MAX) * 0.5f;
            float checkpointRadius = global_scale * 0.01f * scaleFactor;

            if (!doesOverlap(position, checkpointRadius)) {
                Obstacle checkpoint;
                checkpoint.position = position;
                checkpoint.radius = checkpointRadius;

                // Random rotation around Y-axis
                checkpoint.rotationY = (rand() / static_cast<float>(RAND_MAX)) * 360.0f;

                // Random scaling for the checkpoint
                checkpoint.scale = scaleFactor;
                if (i == 0) {
                    checkpoint.checkStatus = 1;
                }
                checkpoint.generateCheckpointMesh();
                obstacles.push_back(checkpoint);
                placed = true;
            }
        }
    }
}

void Tema2::RenderMesh(Mesh *mesh, Shader *shader, const glm::mat4 &modelMatrix, implemented::Camera *camera) {
    if (!mesh || !shader || !shader->GetProgramID())
        return;

    glUseProgram(shader->program);

    // Get shader location for uniform mat4 "Model"
    GLint modelLoc = glGetUniformLocation(shader->GetProgramID(), "Model");

    // Set shader uniform "Model" to modelMatrix
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));

    // Get shader location for uniform mat4 "View"
    GLint viewLoc = glGetUniformLocation(shader->GetProgramID(), "View");

    // Set shader uniform "View" to viewMatrix
    glm::mat4 viewMatrix = (camera) ? camera->GetViewMatrix() : glm::mat4(1.0f);
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(viewMatrix));

    // Get shader location for uniform mat4 "Projection"
    GLint projLoc = glGetUniformLocation(shader->GetProgramID(), "Projection");

    // Set shader uniform "Projection" to projectionMatrix
    glm::mat4 projectionMatrx = projectionMatrix;
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projectionMatrx));

    GLint timeLoc = glGetUniformLocation(shader->GetProgramID(), "Time");

    if (timeLoc != -1) {
        glUniform1f(timeLoc, (GLfloat) Engine::GetElapsedTime());
    }

    // Draw the object
    glBindVertexArray(mesh->GetBuffers()->m_VAO);
    glDrawElements(mesh->GetDrawMode(), static_cast<int>(mesh->indices.size()),
                   GL_UNSIGNED_INT, nullptr);
}

// Standard CreateMesh function
void tema2::CreateMesh(Mesh *targetMesh, const vector<VertexFormat> &vertices,
                  const vector<unsigned int> &indices) {
    unsigned int VAO = 0;
    // Create the VAO and bind it
    glGenVertexArrays(1, &VAO);
    glBindVertexArray(VAO);

    // Create the VBO and bind it
    unsigned int VBO;
    glGenBuffers(1, &VBO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);

    // Send vertices data into the VBO buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices[0]) * vertices.size(),
                 &vertices[0], GL_STATIC_DRAW);

    // Create the IBO and bind it
    unsigned int IBO;
    glGenBuffers(1, &IBO);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IBO);

    // Send indices data into the IBO buffer
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices[0]) * indices.size(),
                 &indices[0], GL_STATIC_DRAW);

    // Set vertex position attribute
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(VertexFormat),
                          nullptr);

    // Set vertex normal attribute
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(VertexFormat),
                          (void *) (sizeof(glm::vec3)));

    // Set texture coordinate attribute
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(VertexFormat),
                          (void *) (2 * sizeof(glm::vec3)));

    // Set vertex color attribute
    glEnableVertexAttribArray(3);
    glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, sizeof(VertexFormat),
                          (void *) (2 * sizeof(glm::vec3) + sizeof(glm::vec2)));
    // ========================================================================

    // Unbind the VAO
    glBindVertexArray(0);

    // Check for OpenGL errors
    CheckOpenGLError();

    // Mesh information is saved into a Mesh object
    targetMesh->InitFromBuffer(VAO,
                               static_cast<unsigned short>(indices.size()));
    targetMesh->indices = indices;
    targetMesh->vertices = vertices;
}

void addParallelepiped(glm::vec3 center, float length, float width, float height,
                       glm::vec3 color, vector<VertexFormat>& vertices, vector<unsigned int>& indices) {
    float halfL = length / 2.0f;
    float halfW = width / 2.0f;
    float halfH = height / 2.0f;

    unsigned int startIndex = vertices.size();

    // Vertices for the parallelepiped
    vertices.emplace_back(center + glm::vec3(-halfL, -halfH, -halfW), color); // 0: bottom-front-left
    vertices.emplace_back(center + glm::vec3(-halfL, halfH, -halfW), color);  // 1: top-front-left
    vertices.emplace_back(center + glm::vec3(halfL, halfH, -halfW), color);   // 2: top-front-right
    vertices.emplace_back(center + glm::vec3(halfL, -halfH, -halfW), color);  // 3: bottom-front-right
    vertices.emplace_back(center + glm::vec3(-halfL, -halfH, halfW), color);  // 4: bottom-back-left
    vertices.emplace_back(center + glm::vec3(-halfL, halfH, halfW), color);   // 5: top-back-left
    vertices.emplace_back(center + glm::vec3(halfL, halfH, halfW), color);    // 6: top-back-right
    vertices.emplace_back(center + glm::vec3(halfL, -halfH, halfW), color);   // 7: bottom-back-right

    // Indices for the parallelepiped faces
    indices.insert(indices.end(), {
            startIndex, startIndex + 1, startIndex + 2, startIndex + 2, startIndex + 3, startIndex, // Front
            startIndex + 1, startIndex + 5, startIndex + 6, startIndex + 6, startIndex + 2, startIndex + 1, // Right
            startIndex + 5, startIndex + 4, startIndex + 7, startIndex + 7, startIndex + 6, startIndex + 5, // Back
            startIndex + 4, startIndex, startIndex + 3, startIndex + 3, startIndex + 7, startIndex + 4, // Left
            startIndex + 3, startIndex + 2, startIndex + 6, startIndex + 6, startIndex + 7, startIndex + 3, // Top
            startIndex + 4, startIndex + 5, startIndex + 1, startIndex + 1, startIndex + 0, startIndex + 4  // Bottom
    });
}

Mesh *tema2::generateTerrainMesh() {
    vector<VertexFormat> vertices;
    vector<unsigned int> indices;

    float global_scale_loc = global_scale + 50.0f;

    const int gridSizeX = (int) (global_scale_loc / (global_scale_loc / 100));
    const int gridSizeZ = (int) (global_scale_loc / (global_scale_loc / 100));

    const float cellSize = global_scale_loc / (float) (gridSizeX - 1);

    for (int i = 0; i < gridSizeZ; ++i) {
        for (int j = 0; j < gridSizeX; ++j) {
            float x = (float) j * cellSize - global_scale_loc / 2.0f;
            float z = (float) i * cellSize - global_scale_loc / 2.0f;
            float y = 0.0f;

            glm::vec3 position = glm::vec3(x, y, z);
            glm::vec3 color = glm::vec3(0.0f, 1.0f, 0.0f);

            vertices.emplace_back(position, color);
        }
    }

    for (int i = 0; i < gridSizeZ - 1; ++i) {
        for (int j = 0; j < gridSizeX - 1; ++j) {
            unsigned int topLeft = i * gridSizeX + j;
            unsigned int topRight = i * gridSizeX + (j + 1);
            unsigned int bottomLeft = (i + 1) * gridSizeX + j;
            unsigned int bottomRight = (i + 1) * gridSizeX + (j + 1);

            indices.push_back(topLeft);
            indices.push_back(bottomLeft);
            indices.push_back(topRight);

            indices.push_back(topRight);
            indices.push_back(bottomLeft);
            indices.push_back(bottomRight);
        }
    }

    Mesh *terrainMesh = new Mesh("terrain");
    CreateMesh(terrainMesh, vertices, indices);
    return terrainMesh;
}

void Obstacle::generateTreeMesh() {
    vector<VertexFormat> vertices;
    vector<unsigned int> indices;

    const float trunkHeight = global_scale * 0.02f;
    const float trunkRadius = global_scale * 0.002f;
    const int trunkSegments = 20;

    // Generate trunk
    for (int i = 0; i <= trunkSegments; ++i) {
        float angle = i * 2.0f * M_PI / trunkSegments;
        float x = trunkRadius * cos(angle);
        float z = trunkRadius * sin(angle);

        glm::vec3 color = glm::vec3(0.55f, 0.27f, 0.07f);
        vertices.emplace_back(glm::vec3(x, 0.0f, z), color);
        vertices.emplace_back(glm::vec3(x, trunkHeight, z), color);
    }

    for (int i = 0; i < trunkSegments; ++i) {
        int baseIndex = i * 2;
        indices.push_back(baseIndex);
        indices.push_back(baseIndex + 1);
        indices.push_back((baseIndex + 2) % (trunkSegments * 2));

        indices.push_back((baseIndex + 2) % (trunkSegments * 2));
        indices.push_back(baseIndex + 1);
        indices.push_back((baseIndex + 3) % (trunkSegments * 2));
    }

    // Generate leaves (two cones)
    const float leavesRadius = global_scale * 0.01f;
    const float leavesHeight = global_scale * 0.015f;
    const int leavesSegments = 20;

    for (int j = 0; j < 2; ++j) {

        float yOffset = trunkHeight + j * leavesHeight * 0.8f;

        glm::vec3 apex = glm::vec3(0.0f, yOffset + leavesHeight, 0.0f);
        vertices.emplace_back(apex, glm::vec3(0.0f, 0.8f, 0.0f));

        int apexIndex = static_cast<int>(vertices.size()) - 1;

        for (int i = 0; i < leavesSegments; ++i) {
            float angle = i * 2.0f * M_PI / leavesSegments;
            float x = leavesRadius * cos(angle);
            float z = leavesRadius * sin(angle);

            glm::vec3 baseVertex = glm::vec3(x, yOffset, z);
            vertices.emplace_back(baseVertex, glm::vec3(0.0f, 0.8f, 0.0f));
        }

        int baseStartIndex = (int) vertices.size() - leavesSegments;

        for (int i = 0; i < leavesSegments; ++i) {
            int next = (i + 1) % leavesSegments;
            indices.push_back(apexIndex);
            indices.push_back(baseStartIndex + i);
            indices.push_back(baseStartIndex + next);
        }
    }

    this->mesh = new Mesh("tree");
    CreateMesh(this->mesh, vertices, indices);
}

void Obstacle::generateBuildingMesh() {
    vector<VertexFormat> vertices;
    vector<unsigned int> indices;

    const float baseWidth = global_scale * 0.05f;
    const float baseHeight = global_scale * 0.03f;
    const float roofHeight = global_scale * 0.015f;

    glm::vec3 baseColor = glm::vec3(0.5f, 0.5f, 0.5f);
    glm::vec3 roofColor = glm::vec3(0.7f, 0.0f, 0.0f);

    // Base vertices
    vertices = {
            VertexFormat(glm::vec3(-baseWidth / 2, 0.0f, -baseWidth / 2), baseColor), // 0
            VertexFormat(glm::vec3(baseWidth / 2, 0.0f, -baseWidth / 2), baseColor),  // 1
            VertexFormat(glm::vec3(baseWidth / 2, baseHeight, -baseWidth / 2), baseColor), // 2
            VertexFormat(glm::vec3(-baseWidth / 2, baseHeight, -baseWidth / 2), baseColor), // 3
            VertexFormat(glm::vec3(-baseWidth / 2, 0.0f, baseWidth / 2), baseColor), // 4
            VertexFormat(glm::vec3(baseWidth / 2, 0.0f, baseWidth / 2), baseColor),  // 5
            VertexFormat(glm::vec3(baseWidth / 2, baseHeight, baseWidth / 2), baseColor), // 6
            VertexFormat(glm::vec3(-baseWidth / 2, baseHeight, baseWidth / 2), baseColor)  // 7
    };

    // Indices base
    indices = {
            0, 1, 2, 2, 3, 0,  // Front
            1, 5, 6, 6, 2, 1,  // Right
            5, 4, 7, 7, 6, 5,  // Back
            4, 0, 3, 3, 7, 4,  // Left
            3, 2, 6, 6, 7, 3,  // Top
            4, 5, 1, 1, 0, 4   // Bottom
    };

    // Duplicate vertices for the roof (distinct color)
    unsigned int roofStartIndex = static_cast<int>(vertices.size());

    vertices.emplace_back(glm::vec3(-baseWidth / 2, baseHeight, -baseWidth / 2), roofColor); // 8
    vertices.emplace_back(glm::vec3(baseWidth / 2, baseHeight, -baseWidth / 2), roofColor);  // 9
    vertices.emplace_back(glm::vec3(baseWidth / 2, baseHeight, baseWidth / 2), roofColor);   // 10
    vertices.emplace_back(glm::vec3(-baseWidth / 2, baseHeight, baseWidth / 2), roofColor);  // 11

    vertices.emplace_back(glm::vec3(0.0f, baseHeight + roofHeight, 0.0f), roofColor); // 12

    indices.insert(indices.end(), {
            roofStartIndex + 1, roofStartIndex + 4, roofStartIndex + 2,  // Right face
            roofStartIndex + 2, roofStartIndex + 4, roofStartIndex + 3,  // Back face
            roofStartIndex + 3, roofStartIndex + 4, roofStartIndex + 0,  // Left face
            roofStartIndex + 0, roofStartIndex + 4, roofStartIndex + 1   // Front face
    });

    this->mesh = new Mesh("building");
    CreateMesh(this->mesh, vertices, indices);
}

    void Obstacle::generateCheckpointMesh() {
        vector<VertexFormat> vertices;
        vector<unsigned int> indices;

        const float gateSize = global_scale * 0.013f;
        const float frameThickness = global_scale * 0.001f;
        const float poleHeight = global_scale * 0.04f;
        const float poleWidth = frameThickness;
        const float poleXOffset = gateSize * 0.57f;

        glm::vec3 poleColor = glm::vec3(0.8f, 0.8f, 0.5f);

        float gateYOffset = poleHeight + gateSize * 0.5f;
        float halfGateSize = gateSize / 2.0f;

        // Add poles beneath square frame
        for (int pole = 0; pole < 2; ++pole) {
            float xOffset = (pole == 0 ? -poleXOffset : poleXOffset);

            addParallelepiped(
                    glm::vec3(xOffset, poleHeight / 2.0f, 0.0f),
                    poleWidth, poleWidth, poleHeight,
                    poleColor, vertices, indices
            );
        }

        // Add gate contour at top of poles
        // Top edge
        addParallelepiped(
                glm::vec3(0.0f, gateYOffset + 0.28f, 0.0f),
                gateSize + 0.85f, frameThickness, frameThickness,
                poleColor, vertices, indices
        );

        // Bottom edge
        addParallelepiped(
                glm::vec3(0.0f, gateYOffset - gateSize - 0.28f, 0.0f),
                gateSize + 0.85f, frameThickness, frameThickness,
                poleColor, vertices, indices
        );

        // Left edge
        addParallelepiped(
                glm::vec3(-poleXOffset, gateYOffset - halfGateSize, 0.0f),
                frameThickness, frameThickness, gateSize + 0.28f,
                poleColor, vertices, indices
        );

        // Right edge
        addParallelepiped(
                glm::vec3(poleXOffset, gateYOffset - halfGateSize, 0.0f),
                frameThickness,frameThickness, gateSize + 0.28f,
                poleColor, vertices, indices
        );

        // Add gate for active checkpoint
        if (this->checkStatus > 0) {
            glm::vec3 frameColor;
            glm::vec3 stopColor = glm::vec3(0.0f, 0.0f, 0.0f);
            float zOffset = 0.0f;
            if (this->checkStatus == 1) {
                frameColor = glm::vec3(1.0f, 0.4f, 0.0f);
                zOffset = 0.1f;
            } else {
                frameColor = glm::vec3(0.6f, 0.0f, 1.0f);
            }


            // Top edge
            addParallelepiped(
                    glm::vec3(0.0f, gateYOffset, -zOffset),
                    gateSize, frameThickness / 2, frameThickness,
                    frameColor, vertices, indices
            );

            // Bottom edge
            addParallelepiped(
                    glm::vec3(0.0f, gateYOffset - gateSize, -zOffset),
                    gateSize, frameThickness / 2, frameThickness,
                    frameColor, vertices, indices
            );

            // Left edge
            addParallelepiped(
                    glm::vec3(-halfGateSize, gateYOffset - halfGateSize, -zOffset),
                    frameThickness, frameThickness / 2, gateSize,
                    frameColor, vertices, indices
            );

            // Right edge
            addParallelepiped(
                    glm::vec3(halfGateSize, gateYOffset - halfGateSize, -zOffset),
                    frameThickness, frameThickness / 2, gateSize,
                    frameColor, vertices, indices
            );


            // Add second frame for the blocked side of active checkpoint
            if (this->checkStatus == 1) {

                addParallelepiped(
                        glm::vec3(0.0f, gateYOffset, zOffset),
                        gateSize, frameThickness / 2, frameThickness,
                        stopColor, vertices, indices
                );

                // Bottom edge
                addParallelepiped(
                        glm::vec3(0.0f, gateYOffset - gateSize, zOffset),
                        gateSize, frameThickness / 2, frameThickness,
                        stopColor, vertices, indices
                );

                // Left edge
                addParallelepiped(
                        glm::vec3(-halfGateSize, gateYOffset - halfGateSize,
                                  zOffset),
                        frameThickness, frameThickness / 2, gateSize,
                        stopColor, vertices, indices
                );

                // Right edge
                addParallelepiped(
                        glm::vec3(halfGateSize, gateYOffset - halfGateSize,
                                  zOffset),
                        frameThickness, frameThickness / 2, gateSize,
                        stopColor, vertices, indices
                );
            }
        }

        this->mesh = new Mesh("checkpoint");
        CreateMesh(this->mesh, vertices, indices);
    }

Mesh *tema2::generateTimerInt(float time, float height) {
    vector<VertexFormat> vertices;
    vector<unsigned int> indices;

    glm::vec3 point1 = glm::vec3(0, 0, 0);
    glm::vec3 point2 = glm::vec3(time, height, 0);
    glm::vec3 point3 = glm::vec3(time, 0, 0);
    glm::vec3 point4 = glm::vec3(0, height, 0);

    glm::vec3 color = glm::vec3(0.5, 0.3, 0.1);
    vertices.emplace_back(point1, color);
    vertices.emplace_back(point2, color);
    vertices.emplace_back(point3, color);
    vertices.emplace_back(point4, color);

    indices.push_back(0);
    indices.push_back(1);
    indices.push_back(2);
    indices.push_back(1);
    indices.push_back(3);
    indices.push_back(0);

    Mesh *timerIntMesh = new Mesh("timerInt");
    CreateMesh(timerIntMesh, vertices, indices);
    return timerIntMesh;
}


Mesh *tema2::generateTimerExt(float time, float height) {
    vector<VertexFormat> vertices;
    vector<unsigned int> indices;


    glm::vec3 point1 = glm::vec3(0, 0, 0);
    glm::vec3 point2 = glm::vec3(time, height, 0);
    glm::vec3 point3 = glm::vec3(time,0, 0);
    glm::vec3 point4 = glm::vec3(0, height, 0);

    glm::vec3 color = glm::vec3(0.5, 0.3, 0.1);
    vertices.emplace_back(point1, color);
    vertices.emplace_back(point2, color);
    vertices.emplace_back(point3, color);
    vertices.emplace_back(point4, color);

    indices.push_back(0);
    indices.push_back(2);
    indices.push_back(1);
    indices.push_back(2);
    indices.push_back(1);
    indices.push_back(3);

    Mesh *timerExtMesh = new Mesh("timerExt");
    timerExtMesh->SetDrawMode(GL_LINE_LOOP);
    CreateMesh(timerExtMesh, vertices, indices);
    return timerExtMesh;
}

Mesh* tema2::generateCloud(float radius, glm::vec3 color) {
    vector<VertexFormat> vertices;
    vector<unsigned int> indices;

    const int segments = 20;
    const int stacks = 20;
    const float sphereRadius = radius / 3.5f;

    vector<glm::vec3> sphereOffsets = {
            glm::vec3(0.0f, 0.0f, 0.0f),                      // Center sphere
            glm::vec3(-sphereRadius * 0.7f, 0.0f, 0.0f),      // Left sphere
            glm::vec3(sphereRadius * 0.7f, 0.0f, 0.0f),       // Right sphere
            glm::vec3(0.0f, sphereRadius * 0.6f, 0.0f),       // Top sphere
            glm::vec3(0.0f, -sphereRadius * 0.6f, 0.0f),      // Bottom sphere
            glm::vec3(0.0f, 0.0f, -sphereRadius * 0.7f),      // Back sphere
            glm::vec3(0.0f, 0.0f, sphereRadius * 0.7f)        // Front sphere
    };

    int puffCount = (int) sphereOffsets.size();

    for (int i = 0; i < puffCount; ++i) {
        glm::vec3 puffCenter = sphereOffsets[i];

        for (int stack = 0; stack <= stacks; ++stack) {
            float stackAngle = glm::pi<float>() * (float) stack / stacks;
            float xy = sphereRadius * sin(stackAngle);
            float z = sphereRadius * cos(stackAngle);

            for (int segment = 0; segment <= segments; ++segment) {
                float sectorAngle = glm::two_pi<float>() * (float) segment / segments;

                float x = xy * cos(sectorAngle);
                float y = xy * sin(sectorAngle);

                glm::vec3 vertexPos = puffCenter + glm::vec3(x, z, y);
                vertices.emplace_back(vertexPos, color);
            }
        }

        int baseIndex = i * (segments + 1) * (stacks + 1);

        for (int stack = 0; stack < stacks; ++stack) {
            for (int segment = 0; segment < segments; ++segment) {
                int current = baseIndex + stack * (segments + 1) + segment;
                int next = baseIndex + (stack + 1) * (segments + 1) + segment;

                // Two triangles for each slice
                indices.push_back(current);
                indices.push_back(next);
                indices.push_back(next + 1);

                indices.push_back(current);
                indices.push_back(next + 1);
                indices.push_back(current + 1);
            }
        }
    }

    Mesh* cloudMesh = new Mesh("cloud");
    CreateMesh(cloudMesh, vertices, indices);
    return cloudMesh;
}
