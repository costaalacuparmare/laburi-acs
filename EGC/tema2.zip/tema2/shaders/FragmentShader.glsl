#version 330

in vec3 frag_position;
in vec3 frag_normal;
in vec3 frag_color;
in float noise_value;

out vec4 out_color;

void main() {
    vec3 color1 = vec3(0.8, 0.6, 0.2);
    vec3 color2 = vec3(0.3, 0.6, 0.2);

    vec3 final_color = mix(color1, color2, noise_value);
    out_color = vec4(final_color, 1.0);
}
