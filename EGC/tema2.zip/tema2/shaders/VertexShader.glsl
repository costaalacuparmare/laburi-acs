#version 330

layout(location = 0) in vec3 v_position;
layout(location = 1) in vec3 v_normal;
layout(location = 3) in vec3 v_color;

uniform mat4 Model;
uniform mat4 View;
uniform mat4 Projection;
uniform float Time;

out vec3 frag_position;
out vec3 frag_normal;
out vec3 frag_color;
out float noise_value;

float random (in vec2 st) {
    return fract(sin(dot(st.xy, vec2(-0.430,0.870))) * 43758.5453123);
}

float noise (in vec2 st) {
    vec2 i = floor(st);
    vec2 f = fract(st);

    // Four corners in 2D of a tile
    float a = random(i);
    float b = random(i + vec2(1.0, 0.0));
    float c = random(i + vec2(0.0, 1.0));
    float d = random(i + vec2(1.0, 1.0));

    // Smooth Interpolation

    // Cubic Hermine Curve.  Same as SmoothStep()
    vec2 u = f*f*(3.0-2.0*f);

    // Mix 4 coorners percentages
    return mix(a, b, u.x) +
    (c - a)* u.y * (1.0 - u.x) +
    (d - b) * u.x * u.y;
}

void main() {
    vec3 position = v_position;


    noise_value = noise(position.xz * 5.0);
    noise_value += smoothstep(0.15, 0.2, noise(position.xz * 50.0));
    noise_value -= smoothstep(0.35, 0.4, noise(position.xz * 50.0));

    position.y += noise_value;
    frag_position = position;
    frag_normal = v_normal;
    frag_color = v_color;

    gl_Position = Projection * View * Model * vec4(frag_position, 1.0);
}