#include "lab_m1/tema2/tema2.h"

using namespace std;
using namespace tema2;

Drone::Drone(int size) {
    this->size = size;
    this->position = glm::vec3(0.0f);
    this->radius = 0.0f;
    this->droneMesh = new Mesh("drone");
    this->rotorMesh = new Mesh("rotor");
    this->arrowMesh = new Mesh("arrow");
}

void addParallelepipedHelp(glm::vec3 center, float length, float width, float height,
                              glm::vec3 color, vector<VertexFormat>& vertices, vector<unsigned int>& indices) {
    float halfL = length / 2.0f;
    float halfW = width / 2.0f;
    float halfH = height / 2.0f;

    unsigned int startIndex = vertices.size();

    vertices.emplace_back(center + glm::vec3(-halfL, -halfH, -halfW), color); // 0
    vertices.emplace_back(center + glm::vec3(halfL, -halfH, -halfW), color);  // 1
    vertices.emplace_back(center + glm::vec3(halfL, halfH, -halfW), color);   // 2
    vertices.emplace_back(center + glm::vec3(-halfL, halfH, -halfW), color);  // 3
    vertices.emplace_back(center + glm::vec3(-halfL, -halfH, halfW), color);  // 4
    vertices.emplace_back(center + glm::vec3(halfL, -halfH, halfW), color);   // 5
    vertices.emplace_back(center + glm::vec3(halfL, halfH, halfW), color);    // 6
    vertices.emplace_back(center + glm::vec3(-halfL, halfH, halfW), color);   // 7

    indices.insert(indices.end(), {
            startIndex, startIndex + 1, startIndex + 2, startIndex + 2, startIndex + 3, startIndex, // Front
            startIndex + 1, startIndex + 5, startIndex + 6, startIndex + 6, startIndex + 2, startIndex + 1, // Right
            startIndex + 5, startIndex + 4, startIndex + 7, startIndex + 7, startIndex + 6, startIndex + 5, // Back
            startIndex + 4, startIndex, startIndex + 3, startIndex + 3, startIndex + 7, startIndex + 4, // Left
            startIndex + 3, startIndex + 2, startIndex + 6, startIndex + 6, startIndex + 7, startIndex + 3, // Top
            startIndex + 4, startIndex + 5, startIndex + 1, startIndex + 1, startIndex + 0, startIndex + 4  // Bottom
    });
}

void Drone::generateDroneMesh(glm::vec3 bodyColor) {
    vector<VertexFormat> vertices;
    vector<unsigned int> indices;

    const float armLength = global_scale * 0.01f;
    const float armWidth = global_scale * 0.001f;
    const float armHeight = global_scale * 0.001f;

    addParallelepipedHelp(glm::vec3(0.0f, 0.0f, 0.0f), armLength, armWidth, armHeight, bodyColor,
                      vertices, indices); // Horizontal arm
    addParallelepipedHelp(glm::vec3(0.0f, 0.0f, 0.0f), armWidth, armLength, armHeight, bodyColor,
                      vertices, indices); // Vertical arm

    const float cubeSize = armWidth;
    glm::vec3 rotorOffsets[] = {
            glm::vec3(armLength / 2.0f, 0.12f, 0.0f),  // Right Cube
            glm::vec3(-armLength / 2.0f, 0.12f, 0.0f), // Left Cube
            glm::vec3(0.0f, 0.12f, armLength / 2.0f),  // Front Cube
            glm::vec3(0.0f, 0.12f, -armLength / 2.0f)  // Back Cube
    };

    for (const auto& offset : rotorOffsets) {
        addParallelepipedHelp(offset, cubeSize, cubeSize, cubeSize + 0.23f, bodyColor,
                          vertices, indices);
    }

    // Finalize the drone mesh
    CreateMesh(droneMesh, vertices, indices);
    position = glm::vec3(0.0f, 0.6f, 0.0f);
}


void Drone::generateRotorMesh() const {
    vector<VertexFormat> vertices;
    vector<unsigned int> indices;

    // Rotor dimensions
    const float rotorLength = global_scale * 0.003f;
    const float rotorWidth = global_scale * 0.001f;
    const float rotorHeight = global_scale * 0.00001f;

    glm::vec3 color = glm::vec3(0.0f, 0.0f, 0.0f);

    float halfL = rotorLength / 1.5f;
    float halfW = rotorWidth / 2.0f;
    float halfH = rotorHeight / 2.0f;
    glm::vec3 center = glm::vec3(0.0f);

    unsigned int startIndex = vertices.size();

    vertices.emplace_back(center + glm::vec3(-halfL, -halfH, -halfW), color);
    vertices.emplace_back(center + glm::vec3(halfL, -halfH, -halfW), color);
    vertices.emplace_back(center + glm::vec3(halfL, halfH, -halfW), color);
    vertices.emplace_back(center + glm::vec3(-halfL, halfH, -halfW), color);

    vertices.emplace_back(center + glm::vec3(-halfL, -halfH, halfW), color);
    vertices.emplace_back(center + glm::vec3(halfL, -halfH, halfW), color);
    vertices.emplace_back(center + glm::vec3(halfL, halfH, halfW), color);
    vertices.emplace_back(center + glm::vec3(-halfL, halfH, halfW), color);

    indices.insert(indices.end(), {
        startIndex, startIndex + 1, startIndex + 2, startIndex + 2, startIndex + 3, startIndex, // Front face
        startIndex + 1, startIndex + 5, startIndex + 6, startIndex + 6, startIndex + 2, startIndex + 1, // Right face
        startIndex + 5, startIndex + 4, startIndex + 7, startIndex + 7, startIndex + 6, startIndex + 5, // Back face
        startIndex + 4, startIndex, startIndex + 3, startIndex + 3, startIndex + 7, startIndex + 4, // Left face
        startIndex + 3, startIndex + 2, startIndex + 6, startIndex + 6, startIndex + 7, startIndex + 3, // Top face
        startIndex + 4, startIndex + 5, startIndex + 1, startIndex + 1, startIndex + 0, startIndex + 4 // Bottom face
    });

    CreateMesh(rotorMesh, vertices, indices);
}

void Drone::generateRotorPositions() {
    // Based on drone position
    rotorPositions.clear();
    rotorPositions.emplace_back(position + glm::vec3(global_scale * 0.005f, 0.4f, 0.0f));  // Right rotor
    rotorPositions.emplace_back(position + glm::vec3(-global_scale * 0.005f, 0.4f, 0.0f)); // Left rotor
    rotorPositions.emplace_back(position + glm::vec3(0.0f, 0.4f, global_scale * 0.005f));  // Front rotor
    rotorPositions.emplace_back(position + glm::vec3(0.0f, 0.4f, -global_scale * 0.005f)); // Back rotor
}

void Drone::generateArrow(glm::vec3 color) const {
    vector<VertexFormat> vertices;
    vector<unsigned int> indices;

    const float arrowWidth = global_scale * 0.001f;
    const float arrowHeight = global_scale * 0.001f;
    const float arrowDepth = global_scale * 0.005f;

    vertices = {
            // Base in the YX plane
            VertexFormat(glm::vec3(0.0f, 0.0f, 0.0f), color),          // 0: Base center
            VertexFormat(glm::vec3(arrowWidth, 0.0f, 0.0f), color),     // 1: Right base
            VertexFormat(glm::vec3(0.0f, arrowHeight, 0.0f), color),    // 2: Top base
            VertexFormat(glm::vec3(-arrowWidth, 0.0f, 0.0f), color),    // 3: Left base
            VertexFormat(glm::vec3(0.0f, 0.0f, arrowDepth), color)      // 4: Tip
    };

    indices = {
            0, 1, 4, // Side 1
            0, 2, 4, // Side 2
            0, 3, 4, // Side 3
            1, 2, 3  // Base
    };

    CreateMesh(this->arrowMesh, vertices, indices);
}

glm::mat4 Drone::RenderArrow() const {

    glm::mat4 modelMatrix = glm::mat4(1);
    glm::vec3 checkPos = this->checkpoints[this->gatesPassed].position;

    // Direction and position of arrow
    glm::vec3 direction = glm::normalize(checkPos - this->position);
    float arrowRotationAngle = atan2(direction.x, direction.z);
    glm::vec3 arrowPosition = this->position + glm::vec3(0.0f, 2.0f, 0.0f);

    modelMatrix = glm::mat4(1);
    modelMatrix *= transform3D::Translate(arrowPosition.x, arrowPosition.y, arrowPosition.z);
    modelMatrix *= transform3D::RotateOY(arrowRotationAngle);
    return modelMatrix;
}

glm::mat4 Drone::RenderDrone() const {
    glm::mat4 modelMatrix = glm::mat4(1);
    if (moveMode == 0) {
        modelMatrix *= transform3D::Translate(this->position.x, this->position.y, this->position.z);
        modelMatrix *= transform3D::RotateOY(RADIANS(45));
        modelMatrix *= transform3D::RotateOY(RADIANS(this->rotationAngle));
    } else if (moveMode == 1 || moveMode == 2) {
        modelMatrix *= transform3D::Translate(this->position.x, this->position.y, this->position.z);
        modelMatrix *= orientation;
        modelMatrix *= transform3D::RotateOY(RADIANS(45));
    }
    return modelMatrix;
}

glm::mat4 Drone::RenderRotor(float deltaTimeSeconds, glm::vec3 rotorPosition) {
    glm::mat4 modelMatrix = glm::mat4(1);

    rotorAngle += 250.0f * deltaTimeSeconds;
    if (rotorAngle >= 360.0f)
        rotorAngle -= 360.0f;

    if (moveMode == 0) {
        modelMatrix *= transform3D::Translate(position.x, position.y, position.z);
        modelMatrix *= transform3D::RotateOY(RADIANS(45));
        modelMatrix *= transform3D::RotateOY(RADIANS(rotationAngle));
        modelMatrix *= transform3D::Translate(rotorPosition.x - position.x,
                                              rotorPosition.y - position.y,
                                              rotorPosition.z - position.z);
        modelMatrix *= transform3D::RotateOY(RADIANS(rotorAngle));
    } else if (moveMode == 1 || moveMode == 2) {
        modelMatrix *= transform3D::Translate(position.x, position.y, position.z);
        modelMatrix *= orientation;
        modelMatrix *= transform3D::RotateOY(RADIANS(45));
        modelMatrix *= transform3D::Translate(rotorPosition.x - position.x,
                                              rotorPosition.y - position.y,
                                              rotorPosition.z - position.z);
        modelMatrix *= transform3D::RotateOY(RADIANS(rotorAngle));
    }
    return modelMatrix;
}


void Drone::SimpleMode(float deltaTime, WindowObject *window, float droneSpeed, int drone_type) {
    glm::vec3 forward = glm::vec3(sin(RADIANS(rotationAngle)), 0, cos(RADIANS(rotationAngle)));
    glm::vec3 right = glm::vec3(-forward.z, 0, forward.x);
    glm::vec3 up = glm::vec3(0, 1, 0);

    glm::vec3 movementDirection(0.0f);

    if (drone_type == 1) {
        if (window->KeyHold(GLFW_KEY_W)) movementDirection -= forward;
        if (window->KeyHold(GLFW_KEY_S)) movementDirection += forward;
        if (window->KeyHold(GLFW_KEY_A)) movementDirection += right;
        if (window->KeyHold(GLFW_KEY_D)) movementDirection -= right;
        if (window->KeyHold(GLFW_KEY_Z)) movementDirection -= up;
        if (window->KeyHold(GLFW_KEY_X)) movementDirection += up;
    } else if (drone_type == 2) {
        if (window->KeyHold(GLFW_KEY_UP)) movementDirection -= forward;
        if (window->KeyHold(GLFW_KEY_DOWN)) movementDirection += forward;
        if (window->KeyHold(GLFW_KEY_LEFT)) movementDirection += right;
        if (window->KeyHold(GLFW_KEY_RIGHT)) movementDirection -= right;
        if (window->KeyHold(GLFW_KEY_RIGHT_CONTROL)) movementDirection -= up;
        if (window->KeyHold(GLFW_KEY_KP_0)) movementDirection += up;
    }

    if (glm::length(movementDirection) > 0.0f) {
        movementDirection = glm::normalize(movementDirection);
        lastMovementDirection = movementDirection;
    }

    if (inKnockback) {
        position += knockbackForce * deltaTime;
        knockbackTimer -= deltaTime;

        if (knockbackTimer <= 0.0f) {
            inKnockback = false;
            knockbackForce = glm::vec3(0.0f);
        }
        return;
    }

    if (collision) {
        knockbackForce = -lastMovementDirection * droneSpeed * 0.5f;
        knockbackTimer = 0.2f;
        inKnockback = true;
        collision = false;
    }

    position += movementDirection * deltaTime * droneSpeed;

    if (drone_type == 1) {
        if (window->KeyHold(GLFW_KEY_Q)) rotationAngle += deltaTime * 100.0f;
        if (window->KeyHold(GLFW_KEY_E)) rotationAngle -= deltaTime * 100.0f;
    } else if (drone_type == 2) {
        if (window->KeyHold(GLFW_KEY_SLASH)) rotationAngle -= deltaTime * 100.0f;
        if (window->KeyHold(GLFW_KEY_PERIOD)) rotationAngle += deltaTime * 100.0f;
    }
}

void Drone::AngleMode(float deltaTime, WindowObject *window, float droneSpeed, int drone_type) {
    float gravity = 9.8f;
    float maxPitch = 30.0f;
    float maxRoll = 30.0f;
    float angularAcceleration = 4000.0f;
    float angularFriction = 5.0f;
    float rotationFriction = 3.0f;

    glm::vec3 forward = glm::vec3(sin(RADIANS(rotationAngle)), 0, cos(RADIANS(rotationAngle)));
    glm::vec3 right = glm::vec3(-forward.z, 0, forward.x);
    glm::vec3 up = glm::vec3(0, 1, 0);

    glm::vec3 movementDirection(0.0f);

    if (drone_type == 1) {
        if (window->KeyHold(GLFW_KEY_A)) movementDirection += right;
        if (window->KeyHold(GLFW_KEY_D)) movementDirection -= right;
        if (window->KeyHold(GLFW_KEY_S)) movementDirection += forward;
        if (window->KeyHold(GLFW_KEY_W)) movementDirection -= forward;
    } else if (drone_type == 2) {
        if (window->KeyHold(GLFW_KEY_LEFT)) movementDirection += right;
        if (window->KeyHold(GLFW_KEY_RIGHT)) movementDirection -= right;
        if (window->KeyHold(GLFW_KEY_RIGHT_CONTROL)) movementDirection += forward;
        if (window->KeyHold(GLFW_KEY_KP_0)) movementDirection -= forward;
    }

    if (glm::length(movementDirection) > 0.0f) {
        movementDirection = glm::normalize(movementDirection);
        lastMovementDirection = movementDirection;
    }

    if (inKnockback) {
        position += knockbackForce * deltaTime;
        knockbackTimer -= deltaTime;

        if (knockbackTimer <= 0.0f) {
            inKnockback = false;
            knockbackForce = glm::vec3(0.0f);
        }
        return;
    }

    if (collision) {
        if (position.y < 0.7f) {
            knockbackForce = -lastMovementDirection * droneSpeed * 0.0f;
        } else {
            knockbackForce = -lastMovementDirection * droneSpeed * 0.5f;
        }
        knockbackTimer = 0.2f;
        inKnockback = true;
        collision = false;
    }

    if (drone_type == 1) {
        if (window->KeyHold(GLFW_KEY_Q)) yawVelocity += 500.0f * deltaTime;
        else if (window->KeyHold(GLFW_KEY_E)) yawVelocity -= 500.0f * deltaTime;
        else if (window->KeyHold(GLFW_KEY_S)) pitchVelocity += angularAcceleration * deltaTime;
        else if (window->KeyHold(GLFW_KEY_W)) pitchVelocity -= angularAcceleration * deltaTime;
        else if (window->KeyHold(GLFW_KEY_A)) rollVelocity += angularAcceleration * deltaTime;
        else if (window->KeyHold(GLFW_KEY_D)) rollVelocity -= angularAcceleration * deltaTime;
        else {
            pitchAngle = RADIANS(0);
            rollAngle = RADIANS(0);
        }
    } else if (drone_type == 2) {
        if (window->KeyHold(GLFW_KEY_PERIOD)) yawVelocity += 500.0f * deltaTime;
        else if (window->KeyHold(GLFW_KEY_SLASH)) yawVelocity -= 500.0f * deltaTime;
        else if (window->KeyHold(GLFW_KEY_RIGHT_CONTROL)) pitchVelocity += angularAcceleration * deltaTime;
        else if (window->KeyHold(GLFW_KEY_KP_0)) pitchVelocity -= angularAcceleration * deltaTime;
        else if (window->KeyHold(GLFW_KEY_LEFT)) rollVelocity += angularAcceleration * deltaTime;
        else if (window->KeyHold(GLFW_KEY_RIGHT)) rollVelocity -= angularAcceleration * deltaTime;
        else {
            pitchAngle = RADIANS(0);
            rollAngle = RADIANS(0);
        }
    }

    pitchVelocity *= max(0.0f, 1.0f - angularFriction * deltaTime);
    pitchAngle = glm::clamp(pitchAngle + pitchVelocity * deltaTime, -maxPitch, maxPitch);

    rollVelocity *= max(0.0f, 1.0f - angularFriction * deltaTime);
    rollAngle = glm::clamp(rollAngle + rollVelocity * deltaTime, -maxRoll, maxRoll);

    yawVelocity *= max(0.0f, 1.0f - rotationFriction * deltaTime);
    rotationAngle += yawVelocity * deltaTime;

    glm::mat4 pitchRotation = transform3D::RotateOX(RADIANS(pitchAngle));
    glm::mat4 rollRotation = transform3D::RotateOZ(RADIANS(rollAngle));
    glm::mat4 yawRotation = transform3D::RotateOY(RADIANS(rotationAngle));
    orientation = yawRotation * pitchRotation * rollRotation;

    glm::vec3 upVector = glm::vec3(orientation * glm::vec4(0, 1, 0, 0));

    glm::vec3 gravityForce = (position.y > 0.7f) ? glm::vec3(0, -gravity * deltaTime, 0) : glm::vec3(0);
    if (position.y <= 0.7f) {
        position.y = 0.8f;
        pitchAngle = 0.0f;
        rollAngle = 0.0f;
    }

    if (drone_type == 1) {
        if (window->KeyHold(GLFW_KEY_LEFT_SHIFT)) {
            if (thrust > 10.0f) {
                thrust = 10.0f;
            } else {
                thrust += 0.3f;
            }
        if (window->KeyHold(GLFW_KEY_1)) {
            if (thrust > 10.0f) {
                thrust = 10.0f;
            } else {
                thrust += 0.03f;
            }
        }
        } else {
            thrust -= 0.2f;
            thrust = max(0.0f, thrust);
        }
    } else if (drone_type == 2) {
        if (window->KeyHold(GLFW_KEY_UP)){
            if (thrust > 10.0f) {
                thrust = 10.0f;
            } else {
                thrust += 0.3f;
            }
        }
        if (window->KeyHold(GLFW_KEY_DOWN)) {
            if (thrust > 10.0f) {
                thrust = 10.0f;
            } else {
                thrust += 0.03f;
            }
        } else {
            thrust -= 0.2f;
            thrust = max(0.0f, thrust);
        }
    }
    glm::vec3 thrustForce = upVector * thrust * droneSpeed * deltaTime;
    thrustForce *= max(0.0f, 0.5f - angularFriction * deltaTime);

    position += thrustForce + gravityForce;
}



void Drone::AcroMode(float deltaTime, WindowObject *window, float droneSpeed, int drone_type) {
    float gravity = 9.8f;
    float angularAcceleration = 1000.0f;
    float angularFriction = 5.0f;

    glm::vec3 forward = glm::vec3(sin(RADIANS(rotationAngle)), 0, cos(RADIANS(rotationAngle)));
    glm::vec3 right = glm::vec3(-forward.z, 0, forward.x);
    glm::vec3 up = glm::vec3(0, 1, 0);

    glm::vec3 movementDirection(0.0f);

    if (drone_type == 1) {
        if (window->KeyHold(GLFW_KEY_A)) movementDirection += right;
        if (window->KeyHold(GLFW_KEY_D)) movementDirection -= right;
        if (window->KeyHold(GLFW_KEY_S)) movementDirection += forward;
        if (window->KeyHold(GLFW_KEY_W)) movementDirection -= forward;
    } else if (drone_type == 2) {
        if (window->KeyHold(GLFW_KEY_LEFT)) movementDirection += right;
        if (window->KeyHold(GLFW_KEY_RIGHT)) movementDirection -= right;
        if (window->KeyHold(GLFW_KEY_RIGHT_CONTROL)) movementDirection += forward;
        if (window->KeyHold(GLFW_KEY_KP_0)) movementDirection -= forward;
    }

    if (glm::length(movementDirection) > 0.0f) {
        movementDirection = glm::normalize(movementDirection);
        lastMovementDirection = movementDirection;
    }

    if (inKnockback) {
        position += knockbackForce * deltaTime;
        knockbackTimer -= deltaTime;

        if (knockbackTimer <= 0.0f) {
            inKnockback = false;
            knockbackForce = glm::vec3(0.0f);
        }
        return;
    }

    if (collision) {
        if (position.y < 0.7f) {
            knockbackForce = -lastMovementDirection * droneSpeed * 0.0f;
        } else {
            knockbackForce = -lastMovementDirection * droneSpeed * 0.5f;
        }
        knockbackTimer = 0.2f;
        inKnockback = true;
        collision = false;
    }

    if (drone_type == 1) {
        if (window->KeyHold(GLFW_KEY_Q)) yawVelocity += angularAcceleration * deltaTime;
        if (window->KeyHold(GLFW_KEY_E)) yawVelocity -= angularAcceleration * deltaTime;
        if (window->KeyHold(GLFW_KEY_S)) pitchVelocity += angularAcceleration * deltaTime;
        if (window->KeyHold(GLFW_KEY_W)) pitchVelocity -= angularAcceleration * deltaTime;
        if (window->KeyHold(GLFW_KEY_A)) rollVelocity += angularAcceleration * deltaTime;
        if (window->KeyHold(GLFW_KEY_D)) rollVelocity -= angularAcceleration * deltaTime;
    } else if (drone_type == 2) {
        if (window->KeyHold(GLFW_KEY_PERIOD)) yawVelocity += angularAcceleration * deltaTime;
        if (window->KeyHold(GLFW_KEY_SLASH)) yawVelocity -= angularAcceleration * deltaTime;
        if (window->KeyHold(GLFW_KEY_RIGHT_CONTROL)) pitchVelocity += angularAcceleration * deltaTime;
        if (window->KeyHold(GLFW_KEY_KP_0)) pitchVelocity -= angularAcceleration * deltaTime;
        if (window->KeyHold(GLFW_KEY_LEFT)) rollVelocity += angularAcceleration * deltaTime;
        if (window->KeyHold(GLFW_KEY_RIGHT)) rollVelocity -= angularAcceleration * deltaTime;
    }

    pitchVelocity *= max(0.0f, 1.0f - angularFriction * deltaTime);
    pitchAngle += pitchVelocity * deltaTime;

    rollVelocity *= max(0.0f, 1.0f - angularFriction * deltaTime);
    rollAngle += rollVelocity * deltaTime;

    yawVelocity *= max(0.0f, 1.0f - angularFriction * deltaTime);
    rotationAngle += yawVelocity * deltaTime;

    glm::mat4 pitchRotation = transform3D::RotateOX(RADIANS(pitchAngle));
    glm::mat4 rollRotation = transform3D::RotateOZ(RADIANS(rollAngle));
    glm::mat4 yawRotation = transform3D::RotateOY(RADIANS(rotationAngle));
    orientation = yawRotation * pitchRotation * rollRotation;

    glm::vec3 gravityForce = glm::vec3(0, -gravity * deltaTime, 0);
    if (position.y < 0.7f) {
        gravityForce = glm::vec3(0);
        position.y = 0.7f;
        pitchAngle = 0.0f;
        rollAngle = 0.0f;
    }

    glm::vec3 upVector = glm::vec3(orientation * glm::vec4(0, 1, 0, 0));

    if (drone_type == 1) {
        if (window->KeyHold(GLFW_KEY_LEFT_SHIFT)) {
            if (thrust > 10.0f) {
                thrust = 10.0f;
            } else {
                thrust += 0.1f;
            }
        }
        if (window->KeyHold(GLFW_KEY_1)) {
            if (thrust > 10.0f) {
                thrust = 10.0f;
            } else {
                thrust += 0.01f;
            }
        } else {
            thrust -= 0.05f;
            thrust = max(0.0f, thrust);
        }
    } else if (drone_type == 2) {
        if (window->KeyHold(GLFW_KEY_UP)) {
            if (thrust > 10.0f) {
                thrust = 10.0f;
            } else {
                thrust += 0.1f;
            }
        }
        if (window->KeyHold(GLFW_KEY_DOWN)) {
            if (thrust > 10.0f) {
                thrust = 10.0f;
            } else {
                thrust += 0.01f;
            }
        } else {
            thrust -= 0.05f;
            thrust = max(0.0f, thrust);
        }
    }

    glm::vec3 thrustForce = upVector * thrust * droneSpeed * deltaTime;
    thrustForce *= max(0.0f, 1.0f - angularFriction * deltaTime);
    position += thrustForce + gravityForce;
}



