#include "lab_m1/tema1/tema1.h"

using namespace std;
using namespace tema1;

Tank::Tank(float x, float y, float baseWidth, float topWidth, float height,
           float initAngle) {
    this->x = x;
    this->y = y;
    this->baseWidth = baseWidth;
    this->topWidth = topWidth;
    this->height = height;
    this->bodyMesh = new Mesh("body");
    this->turretMesh = new Mesh("turret");
    this->bodyAngle = 0;
    this->turretAngle = initAngle;
    this->trajMesh = new Mesh("trajectory");
    this->projMesh = new Mesh("projectile");
    this->lifePoints = 10;
    this->HealthBarExt = new Mesh("healthBarExt");
    this->HealthBarInt = new Mesh("healthBarInt");
    this->turretPosition = glm::vec3(0, 0, 0);
    this->explosionMesh = new Mesh("explosion");
    this->explX = 0.1f;
    this->explY = 0.1f;
}

float Tank::getXPos() const {
    return this->x;
}

float Tank::getYPos() const {
    return this->y;
}

float Tank::getTurretAngle() const {
    return this->turretAngle;
}

Mesh *Tank::getBodyMesh() const {
    return this->bodyMesh;
}

Mesh *Tank::getTurretMesh() const {
    return this->turretMesh;
}

Mesh *Tank::getProjMesh() const {
    return this->projMesh;
}

Mesh *Tank::getTrajMesh() const {
    return this->trajMesh;
}

Mesh *Tank::getExplosionMesh() const {
    return this->explosionMesh;
}

glm::vector<Projectile> Tank::getProj() {
    return this->projectiles;
}

float Tank::getBaseWidth() const {
    return this->baseWidth;
}

float Tank::getLifePoints() const {
    return this->lifePoints;
}

float Tank::getBodyAngle() const {
    return this->bodyAngle;
}

Mesh *Tank::getHealthIntMesh() const {
    return this->HealthBarInt;
}

Mesh *Tank::getHealthExtMesh() const {
    return this->HealthBarExt;
}

void Tank::setXPos(float coordX) {
    this->x = coordX;
}

void Tank::setYPos(float coordY) {
    this->y = coordY;
}

void Tank::setTurretAngle(float angleNew) {
    this->turretAngle = angleNew;
}

void Tank::hit() {
    this->lifePoints -= 2;
}

void Tank::respawn(float newX, float newY) {
    this->x = newX;
    this->y = newY;
    this->explX = 0.1f;
    this->explY = 0.1f;
    this->lifePoints = 10;
}

void Tank::GenerateBody(glm::vec3 colorRails, glm::vec3 colorBody) const {
    std::vector<VertexFormat> vertices;
    std::vector<unsigned int> indices;

    glm::vec3 point1 = glm::vec3(x - baseWidth / 2, y, 0);
    glm::vec3 point2 = glm::vec3(x + baseWidth / 2, y, 0);
    glm::vec3 point3 = glm::vec3(x + topWidth / 2, y + height, 0);
    glm::vec3 point4 = glm::vec3(x - topWidth / 2, y + height, 0);

    vertices.emplace_back(point1, colorRails);
    vertices.emplace_back(point2, colorRails);
    vertices.emplace_back(point3, colorRails);
    vertices.emplace_back(point4, colorRails);

    indices.push_back(0);
    indices.push_back(1);
    indices.push_back(2);
    indices.push_back(2);
    indices.push_back(3);
    indices.push_back(0);

    // second trapeze that starts where the first one ends (above it)
    point1 = glm::vec3(x + topWidth / 2 + 2, y + height, 0);
    point2 = glm::vec3(x - topWidth / 2 - 2, y + height, 0);
    point3 = glm::vec3(x - topWidth / 2 + 0.5f, y + 3 + height, 0);
    point4 = glm::vec3(x + topWidth / 2 - 0.5f, y + 3 + height, 0);

    vertices.emplace_back(point1, colorBody);
    vertices.emplace_back(point2, colorBody);
    vertices.emplace_back(point3, colorBody);
    vertices.emplace_back(point4, colorBody);

    indices.push_back(4);
    indices.push_back(5);
    indices.push_back(6);
    indices.push_back(6);
    indices.push_back(7);
    indices.push_back(4);

    // add semicircle
    int numPoints = 100;
    float radius = topWidth / 2 - 3.5f;
    float angle = 0;
    float step = M_PI / numPoints;

    glm::vec3 center = glm::vec3(x, y + 4.9f, 0);

    unsigned int indexCenter = vertices.size();
    vertices.emplace_back(center, colorBody);

    // create circle points
    for (int i = 0; i < numPoints; i++) {
        glm::vec3 point = glm::vec3(center.x + radius * cos(angle),
                                    center.y + radius * sin(angle), 0);
        vertices.emplace_back(point, colorBody);
        angle += step;
    }

    //add indices for the semicircle
    for (int i = 1; i < numPoints; i++) {
        indices.push_back(indexCenter);
        indices.push_back(indexCenter + i);
        indices.push_back(indexCenter + i + 1);
    }

    CreateMesh(bodyMesh, vertices, indices);
}

void Tank::GenerateTurret(glm::vec3 color) const {
    std::vector<VertexFormat> vertices;
    std::vector<unsigned int> indices;

    glm::vec3 point1 = glm::vec3(0, y + 1, 0);
    glm::vec3 point2 = glm::vec3(1, y + 1, 0);
    glm::vec3 point3 = glm::vec3(1, y + 7.5f, 0);
    glm::vec3 point4 = glm::vec3(0, y + 7.5f, 0);

    vertices.emplace_back(point1, color);
    vertices.emplace_back(point2, color);
    vertices.emplace_back(point3, color);
    vertices.emplace_back(point4, color);

    indices.push_back(0);
    indices.push_back(1);
    indices.push_back(2);
    indices.push_back(2);
    indices.push_back(3);
    indices.push_back(0);

    CreateMesh(turretMesh, vertices, indices);
}


glm::mat3 Tank::RenderTank(const glm::vector<float> &heightMap, float step) {
    glm::mat3 modelMatrix = glm::mat3(1);

    float x1 = 0;
    while (x1 <= x) {
        x1 += step;
    }
    float x2 = x1 + step;
    float y1 = heightMap[(int) (x1 / step)];
    float y2 = heightMap[(int) (x2 / step)];

    float t = (x - x1) / (x2 - x1);
    y = y1 + t * (y2 - y1);

    bodyAngle = atan((y2 - y1) / (x2 - x1));

    modelMatrix *= transform2D::Translate(x, y);
    modelMatrix *= transform2D::Scale(3, 3);
    modelMatrix *= transform2D::Rotate(bodyAngle);
    return modelMatrix;
}

glm::mat3 Tank::RenderTurret() {
    glm::mat3 modelMatrix = glm::mat3(1);
    modelMatrix *= transform2D::Translate(x, y);
    modelMatrix *= transform2D::Scale(3, 3);
    modelMatrix *= transform2D::Rotate(bodyAngle);
    modelMatrix *= transform2D::Translate(0, 7);
    modelMatrix *= transform2D::Rotate(turretAngle);

    turretPosition = modelMatrix * glm::vec3(0, 0, 1);

    return modelMatrix;
}

void Tank::CreateTrajectory(float initialSpeed) {
    trajectory.clear();

    auto angle = (float) (turretAngle + 0.5f * M_PI + bodyAngle);

    float velocityX = cos(angle) * initialSpeed;
    float velocityY = sin(angle) * initialSpeed;

    float g = 9.8f;
    int numPoints = 500;
    for (int i = 0; i < numPoints; ++i) {
        float t = (float) i * 0.05f;

        float posX = turretPosition.x + velocityX * t;
        float posY = turretPosition.y + velocityY * t - 0.5f * g * t * t;

        if (posY < 0) break;

        trajectory.emplace_back(posX, posY, 0);
    }
}


void Tank::GenerateTrajectory() {
    vector<VertexFormat> vertices;
    vector<unsigned int> indices;

    for (size_t i = 0; i < trajectory.size(); ++i) {
        glm::vec3 point = trajectory[i];
        vertices.emplace_back(point, glm::vec4(0.871, 0.871, 0.871, 0.671));
        indices.push_back(i);
    }

    trajMesh->SetDrawMode(GL_LINE_STRIP);
    CreateMesh(trajMesh, vertices, indices);
}


void Tank::GenerateProjectile() const {
    vector<VertexFormat> vertices;
    vector<unsigned int> indices;

    int numPoints = 1000;
    float radius = topWidth / 2 - 2.5f;
    float angle = 0;

    glm::vec3 center = glm::vec3(0, 0, 0);

    glm::vec3 color = glm::vec3(0.478, 0.478, 0.42);

    unsigned int indexCenter = vertices.size();
    float step = 2.0f * (float) (M_PI / numPoints);
    vertices.emplace_back(center, color);

    for (int i = 0; i < numPoints; i++) {
        glm::vec3 point = glm::vec3(center.x + radius * cos(angle),
                                    center.y + radius * sin(angle), 0);
        vertices.emplace_back(point, color);
        angle += step;
    }

    for (int i = 1; i < numPoints; i++) {
        indices.push_back(indexCenter);
        indices.push_back(indexCenter + i);
        indices.push_back(indexCenter + i + 1);
    }

    CreateMesh(projMesh, vertices, indices);
}

void Tank::LaunchProjectile(float speed) {


    Projectile proj{};
    proj.position = turretPosition;
    auto angle = (float) (turretAngle + 0.5f * M_PI + bodyAngle);
    proj.velocity.x = speed * cos(angle);
    proj.velocity.y = speed * sin(angle);
    proj.isActive = true;

    projectiles.push_back(proj);
}

void Tank::UpdateProjectiles(float deltaTime) {
    for (auto &proj: projectiles) {
        if (proj.isActive) {
            proj.position.x += proj.velocity.x * 6 * deltaTime;
            proj.position.y += proj.velocity.y * 6 * deltaTime;
            proj.velocity.y -= 9.8f * 6 * deltaTime;
        }
    }
}

void Tank::DeleteProjectile(int idx) {
    projectiles.erase(projectiles.begin() + idx);
}


glm::mat3 Tank::RenderProjectile(Projectile &proj) {
    glm::mat3 modelMatrix = glm::mat3(1);
    modelMatrix *= transform2D::Translate(proj.position.x, proj.position.y);
    return modelMatrix;
}

glm::mat3 Tank::RenderTrajectory() {
    glm::mat3 modelMatrix = glm::mat3(1);
    this->CreateTrajectory(70);
    this->GenerateTrajectory();
    return modelMatrix;
}

void Tank::GenerateHealthBarInt() const {
    vector<VertexFormat> vertices;
    vector<unsigned int> indices;

    glm::vec3 point1 = glm::vec3(0, height, 0);
    glm::vec3 point2 = glm::vec3(0 + lifePoints, height + 2, 0);
    glm::vec3 point3 = glm::vec3(0 + lifePoints, height, 0);
    glm::vec3 point4 = glm::vec3(0, height + 2, 0);

    glm::vec3 color = glm::vec3(1, 1, 1);
    vertices.emplace_back(point1, color);
    vertices.emplace_back(point2, color);
    vertices.emplace_back(point3, color);
    vertices.emplace_back(point4, color);

    indices.push_back(0);
    indices.push_back(1);
    indices.push_back(2);
    indices.push_back(1);
    indices.push_back(3);
    indices.push_back(0);

    CreateMesh(HealthBarInt, vertices, indices);
}

void Tank::GenerateHealthBarExt() const {
    vector<VertexFormat> vertices;
    vector<unsigned int> indices;

    glm::vec3 point1 = glm::vec3(0, height, 0);
    glm::vec3 point2 = glm::vec3(0 + lifePoints, height + 2, 0);
    glm::vec3 point3 = glm::vec3(0 + lifePoints, height, 0);
    glm::vec3 point4 = glm::vec3(0, height + 2, 0);

    glm::vec3 color = glm::vec3(1, 1, 1);
    vertices.emplace_back(point1, color);
    vertices.emplace_back(point2, color);
    vertices.emplace_back(point3, color);
    vertices.emplace_back(point4, color);

    indices.push_back(0);
    indices.push_back(2);
    indices.push_back(1);
    indices.push_back(3);

    HealthBarExt->SetDrawMode(GL_LINE_LOOP);
    CreateMesh(HealthBarExt, vertices, indices);
}


glm::mat3 Tank::RenderHealthBar() const {
    glm::mat3 modelMatrix = glm::mat3(1);
    modelMatrix *= transform2D::Translate(x, y + 30);
    modelMatrix *= transform2D::Scale(5, 5);
    return modelMatrix;
}

void Tank::GenerateExplosion() {
    vector<VertexFormat> vertices;
    vector<unsigned int> indices;

    glm::vec3 center = glm::vec3(0, 0, 0);

    const int numCircles = 8;
    const float maxRadius = 10.0f;

    for (int circleIndex = 0; circleIndex < numCircles; circleIndex++) {
        float radius = maxRadius * ((float) (circleIndex + 1) / numCircles);
        int numPoints = 100 + circleIndex * 50;

        glm::vec3 color = glm::mix(glm::vec3(1, 1, 1), glm::vec3(1, 0.6f, 0),
                                   (float) circleIndex / numCircles);

        unsigned int indexCenter = vertices.size();
        vertices.emplace_back(center, color);

        // Generate vertices for the circle
        float angle = 0.0f;
        float step = 2.0f * (float) (M_PI / numPoints);
        for (int i = 0; i < numPoints; i++) {
            glm::vec3 point = glm::vec3(center.x + radius * cos(angle),
                                        center.y + radius * sin(angle), 0);
            vertices.emplace_back(point, color);
            angle += step;
        }

        for (int i = 1; i < numPoints; i++) {
            indices.push_back(indexCenter);
            indices.push_back(indexCenter + i);
            indices.push_back(indexCenter + i + 1);
        }

        indices.push_back(indexCenter);
        indices.push_back(indexCenter + numPoints);
        indices.push_back(indexCenter + 1);
    }

    CreateMesh(explosionMesh, vertices, indices);
}


glm::mat3 Tank::RenderExplosion(float deltaTime) {
    glm::mat3 modelMatrix = glm::mat3(1);
    if (explX < baseWidth / 3 || explY < baseWidth / 3) {
        explX += deltaTime * 8;
        explY += deltaTime * 8;
        modelMatrix *= transform2D::Translate(x, y);
        modelMatrix *= transform2D::Scale(explX, explY);
    }
    return modelMatrix;
}
