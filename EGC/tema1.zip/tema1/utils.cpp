#include "lab_m1/tema1/tema1.h"

using namespace std;
using namespace tema1;

void
tema1::CreateMesh(Mesh *targetMesh, const std::vector<VertexFormat> &vertices,
                  const std::vector<unsigned int> &indices) {
    // Create the VAO and bind it
    unsigned int VAO = 0;
    glGenVertexArrays(1, &VAO);
    glBindVertexArray(VAO);

    // Create the VBO and bind it
    unsigned int VBO = 0;
    glGenBuffers(1, &VBO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);

    // Send vertices data into the VBO buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices[0]) * vertices
                         .size(),
                 &vertices[0], GL_STATIC_DRAW);

    // Create the IBO and bind it
    unsigned int IBO = 0;
    glGenBuffers(1, &IBO);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IBO);

    // Send indices data into the IBO buffer
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices[0]) * indices.size(),
                 &indices[0], GL_STATIC_DRAW);

    // Set vertex position attribute
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(VertexFormat),
                          nullptr);

    // Set vertex normal attribute
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(VertexFormat),
                          (void *) (sizeof(glm::vec3)));

    // Set texture coordinate attribute
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(VertexFormat),
                          (void *) (2 * sizeof(glm::vec3)));

    // Set vertex color attribute
    glEnableVertexAttribArray(3);
    glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, sizeof(VertexFormat),
                          (void *) (2 * sizeof(glm::vec3) + sizeof(glm::vec2)));
    // ========================================================================

    // Unbind the VAO
    glBindVertexArray(0);

    // Mesh information is saved into a Mesh object
    targetMesh->InitFromBuffer(VAO,
                               static_cast<unsigned short>(indices.size()));
}

Mesh *tema1::generateMesh(vector<float> &heightMap, int height, int width) {
    vector<VertexFormat> vertices;
    vector<unsigned int> indices;

    // amplitude and frequency for each sinusoidal component
    float A1 = 45.0f, A2 = 30.0f, A3 = 10.0f;
    float Omega1 = 0.02f, Omega2 = 0.01f, Omega3 = 0.03f;

    int numPoints = 1000;
    heightMap.reserve(numPoints);
    float step = static_cast<float>(width) / (float) (numPoints - 1);

    for (int i = 0; i < numPoints - 1; i++) {

        float x = (float) i * step;
        float y = (float) height / 2 + A1 * sin(Omega1 * x) + A2 * sin
                (Omega2 * x) +
                  A3 * sin(Omega3 * x);
        heightMap.push_back(y);

        // sinusoidal upper points
        glm::vec3 point1 = glm::vec3(x, y, 0);
        glm::vec3 point2 = glm::vec3(x + step, y, 0);

        // lower points
        glm::vec3 point3 = glm::vec3(x, 0.0f, 0);
        glm::vec3 point4 = glm::vec3(x + step, 0.0f, 0);

        // Add the points to the vertices list
        glm::vec3 color = glm::vec3(0.337f, 0.51f, 0.082f);
        vertices.emplace_back(point1, color);
        vertices.emplace_back(point2, color);
        vertices.emplace_back(point3, color);
        vertices.emplace_back(point4, color);

        // Create the indices for the two triangles

        // Left triangle
        indices.push_back(i * 4);
        indices.push_back(i * 4 + 1);
        indices.push_back(i * 4 + 2);

        // Right triangle
        indices.push_back(i * 4 + 2);
        indices.push_back(i * 4 + 1);
        indices.push_back(i * 4 + 3);
    }

    Mesh *terrainMesh = new Mesh("terrain");
    CreateMesh(terrainMesh, vertices, indices);
    return terrainMesh;
}

void
tema1::UpdateTerrainMesh(const glm::vector<float> &heightMap, float terrainStep,
                         Mesh *mesh) {
    std::vector<VertexFormat> vertices;
    std::vector<unsigned int> indices;

    for (int i = 0; i < heightMap.size() - 1; i++) {
        float x = (float) i * terrainStep;
        float y = heightMap[i];

        // upper points
        glm::vec3 point1 = glm::vec3(x, y, 0);
        glm::vec3 point2 = glm::vec3(x + terrainStep, heightMap[i + 1], 0);

        // lower points
        glm::vec3 point3 = glm::vec3(x, 0.0f, 0);
        glm::vec3 point4 = glm::vec3(x + terrainStep, 0.0f, 0);

        glm::vec3 color = glm::vec3(0.337f, 0.51f, 0.082f);
        vertices.emplace_back(point1, color);
        vertices.emplace_back(point2, color);
        vertices.emplace_back(point3, color);
        vertices.emplace_back(point4, color);

        // left triangle
        indices.push_back(i * 4);
        indices.push_back(i * 4 + 1);
        indices.push_back(i * 4 + 2);

        // right triangle
        indices.push_back(i * 4 + 2);
        indices.push_back(i * 4 + 1);
        indices.push_back(i * 4 + 3);
    }

    CreateMesh(mesh, vertices, indices);
}


void tema1::CreateCrater(glm::vector<float> &heightMap, int impactIndex,
                         float impactY, float terrainStep, Mesh *mesh) {
    float craterRadius = 30.0f;
    int radiusInSteps = static_cast<int>(craterRadius / terrainStep);

    for (int i = -radiusInSteps; i <= radiusInSteps; i++) {
        int index = impactIndex + i;

        // ensure index is valid
        if (index >= 0 && index < heightMap.size()) {
            float xDistance = (float) i * terrainStep;

            // calc distance from the center
            float distance = sqrt(xDistance * xDistance);

            if (distance < craterRadius) {
                // circular depression height reduction
                float heightReduction = sqrt(
                        craterRadius * craterRadius - xDistance * xDistance);

                float newHeight = impactY - heightReduction;

                if (newHeight < heightMap[index]) {
                    heightMap[index] = newHeight;
                }
            }
        }
    }

    UpdateTerrainMesh(heightMap, terrainStep, mesh);
}


bool tema1::CheckCollision(Tank *tank, Projectile &proj,
                           glm::vector<float> &heightMap, float terrainStep,
                           Mesh *mesh) {

    if (tank != nullptr) {
        // tank collision detection
        float radius = tank->getBaseWidth() + 5;
        glm::vec3 center = glm::vec3(tank->getXPos(), tank->getYPos() + 4.9f,
                                     0);

        float distance = glm::distance(proj.position, center);

        if (distance <= radius && proj.isActive) {
            if (tank->getLifePoints() >= 0) {
                tank->hit();
                proj.isActive = false;
                return true;
            }
        }
    }

    if (!heightMap.empty()) {
        // terrain collision detection
        int terrainIndex = static_cast<int>(proj.position.x / terrainStep);

        if (terrainIndex < heightMap.size()) {
            float terrainHeight = heightMap[terrainIndex];

            if (proj.position.y > 0 && proj.position.y <= terrainHeight) {
                proj.isActive = false;
                CreateCrater(heightMap, terrainIndex, terrainHeight,
                             terrainStep, mesh);
                return true;
            }
        }
    }

    return false;
}
