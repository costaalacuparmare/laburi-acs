#include "lab_m1/tema1/tema1.h"

using namespace std;
using namespace tema1;

void Tema1::Init() {

    glm::ivec2 resolution = window->GetResolution();
    auto camera = GetSceneCamera();
    camera->SetOrthographic(0, (float) resolution.x, 0, (float) resolution.y,
                            0.01f, 400);
    camera->SetPosition(glm::vec3(0, 0, 50));
    camera->SetRotation(glm::vec3(0, 0, 0));
    camera->Update();
    GetCameraInput()->SetActive(false);

    height = resolution.y;
    width = resolution.x;

    terrainMesh = generateMesh(heightMap, height, width);

    glm::vec3 colorRails = glm::vec3(0, 0, 0);
    glm::vec3 colorBody1 = glm::vec3(0.612f, 0, 0);
    glm::vec3 colorBody2 = glm::vec3(0, 0.086f, 0.62f);

    tank1 = new Tank(0, 0, 10, 15, 2, -1.57135);
    tank1->GenerateBody(colorRails, colorBody1);
    tank1->GenerateTurret(colorRails);
    tank1->GenerateHealthBarExt();
    tank1->GenerateExplosion();
    tank1->setXPos(100);
    tank1->setYPos(428);
    tank1->GenerateProjectile();

    tank2 = new Tank(0, 0, 10, 15, 2, 1.57891);
    tank2->GenerateBody(colorRails, colorBody2);
    tank2->GenerateTurret(colorRails);
    tank2->GenerateHealthBarExt();
    tank2->GenerateExplosion();
    tank2->setXPos(1142);
    tank2->setYPos(302);
    tank2->GenerateProjectile();
}


void Tema1::FrameStart() {
    glClearColor(0, 0.565f, 0.851f, 1);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glm::ivec2 resolution = window->GetResolution();
    // Sets the screen area where to draw
    glViewport(0, 0, resolution.x, resolution.y);
}

void Tema1::SimulateTerrainSliding(float step, float threshold, float friction,
                                   float deltaTime) {
    bool changed = false;

    for (int i = 1; i < heightMap.size() - 1; ++i) {
        float left = heightMap[i - 1];
        float right = heightMap[i + 1];
        float current = heightMap[i];

        // high diff between adjacent points
        float diffLeft = current - left;
        float diffRight = current - right;

        if (abs(diffLeft) > threshold) {
            float transfer = diffLeft * friction * deltaTime;
            heightMap[i - 1] += transfer;
            heightMap[i] -= transfer;
            changed = true;
        }

        if (abs(diffRight) > threshold) {
            float transfer = diffRight * friction * deltaTime;
            heightMap[i + 1] += transfer;
            heightMap[i] -= transfer;
            changed = true;
        }
    }

    if (changed) {
        UpdateTerrainMesh(heightMap, step, terrainMesh);
    }
}


void Tema1::RenderProjectiles(Tank *currentTank, Tank *targetTank, float step) {
    for (int i = 0; i < currentTank->getProj().size(); i++) {
        Projectile proj = currentTank->getProj()[i];
        if (proj.isActive) {
            bool collision = CheckCollision(targetTank, proj, heightMap, step,
                                            terrainMesh);
            if (!collision) {
                modelMatrix = Tank::RenderProjectile(proj);
                RenderMesh2D(currentTank->getProjMesh(), shaders["VertexColor"],
                             modelMatrix);
            } else {
                currentTank->DeleteProjectile(i);
                --i;
            }
        }
    }
}

void Tema1::Update(float deltaTimeSeconds) {
    float step = static_cast<float>(width) / (float) (heightMap.size() - 1);

    SimulateTerrainSliding(step, 0.5f, 2, deltaTimeSeconds);

    if (tank1->getLifePoints() > 0) {
        tank1->GenerateHealthBarInt();
        modelMatrix = tank1->RenderHealthBar();
        RenderMesh2D(tank1->getHealthIntMesh(), shaders["VertexColor"],
                     modelMatrix);
        RenderMesh2D(tank1->getHealthExtMesh(), shaders["VertexColor"],
                     modelMatrix);
    } else {
        modelMatrix = tank1->RenderExplosion(deltaTimeSeconds);
        RenderMesh2D(tank1->getExplosionMesh(), shaders["VertexColor"],
                     modelMatrix);
    }

    if (tank2->getLifePoints() > 0) {
        tank2->GenerateHealthBarInt();
        modelMatrix = tank2->RenderHealthBar();
        RenderMesh2D(tank2->getHealthIntMesh(), shaders["VertexColor"],
                     modelMatrix);
        RenderMesh2D(tank2->getHealthExtMesh(), shaders["VertexColor"],
                     modelMatrix);
    } else {
        modelMatrix = tank2->RenderExplosion(deltaTimeSeconds);
        RenderMesh2D(tank2->getExplosionMesh(), shaders["VertexColor"],
                     modelMatrix);
    }

    modelMatrix = glm::mat3(1);
    RenderMesh2D(terrainMesh, shaders["VertexColor"], modelMatrix);

    tank1->UpdateProjectiles(deltaTimeSeconds);
    RenderProjectiles(tank1, tank2, step);

    if (tank1->getLifePoints() > 0) {
        modelMatrix = tank1->RenderTurret();
        RenderMesh2D(tank1->getTurretMesh(), shaders["VertexColor"],
                     modelMatrix);

        modelMatrix = tank1->RenderTank(heightMap, step);
        RenderMesh2D(tank1->getBodyMesh(), shaders["VertexColor"], modelMatrix);
    }

    tank2->UpdateProjectiles(deltaTimeSeconds);
    RenderProjectiles(tank2, tank1, step);

    if (tank2->getLifePoints() > 0) {
        modelMatrix = tank2->RenderTurret();
        RenderMesh2D(tank2->getTurretMesh(), shaders["VertexColor"],
                     modelMatrix);

        modelMatrix = tank2->RenderTank(heightMap, step);
        RenderMesh2D(tank2->getBodyMesh(), shaders["VertexColor"], modelMatrix);
    }

    if (tank1->getLifePoints() > 0) {
        modelMatrix = tank1->RenderTrajectory();
        RenderMesh2D(tank1->getTrajMesh(), shaders["VertexColor"], modelMatrix);
    }

    if (tank2->getLifePoints() > 0) {
        modelMatrix = tank2->RenderTrajectory();
        RenderMesh2D(tank2->getTrajMesh(), shaders["VertexColor"], modelMatrix);
    }


}


void Tema1::FrameEnd() {
}

void Tema1::OnInputUpdate(float deltaTime, int mods) {
    // move tank 1
    if (window->KeyHold(GLFW_KEY_A)) {
        if (tank1->getXPos() > 3) {
            tank1->setXPos(tank1->getXPos() - 150 * deltaTime -
                           tank1->getBodyAngle() * 0.7f);
        }
    }
    if (window->KeyHold(GLFW_KEY_D)) {
        if (tank1->getXPos() + 150 * deltaTime < (float) width - 10) {
            tank1->setXPos(tank1->getXPos() + 150 * deltaTime -
                           tank1->getBodyAngle() * 0.7f);
        }
    }
    if (window->KeyHold(GLFW_KEY_W)) {
        if (tank1->getTurretAngle() < M_PI / 2) {
            tank1->setTurretAngle(tank1->getTurretAngle() + 3 * deltaTime);
        }
    }
    if (window->KeyHold(GLFW_KEY_S)) {
        if (tank1->getTurretAngle() > -M_PI / 2) {
            tank1->setTurretAngle(tank1->getTurretAngle() - 3 * deltaTime);
        }
    }

    // move tank 2
    if (window->KeyHold(GLFW_KEY_LEFT)) {
        if (tank2->getXPos() > 3) {
            tank2->setXPos(tank2->getXPos() - 150 * deltaTime -
                           tank2->getBodyAngle() * 0.7f);
        }
    }
    if (window->KeyHold(GLFW_KEY_RIGHT)) {
        if (tank2->getXPos() - 150 * deltaTime < (float) width - 10) {
            tank2->setXPos(tank2->getXPos() + 150 * deltaTime -
                           tank2->getBodyAngle() * 0.7f);
        }
    }
    if (window->KeyHold(GLFW_KEY_UP)) {
        if (tank2->getTurretAngle() > -M_PI / 2) {
            tank2->setTurretAngle(tank2->getTurretAngle() - 3 * deltaTime);
        }
    }
    if (window->KeyHold(GLFW_KEY_DOWN)) {
        if (tank2->getTurretAngle() < M_PI / 2) {
            tank2->setTurretAngle(tank2->getTurretAngle() + 3 * deltaTime);
        }
    }

    if (window->KeyHold(GLFW_KEY_V)) {
        float step = static_cast<float>(width) / (float) (heightMap.size() - 1);
        SimulateTerrainSliding(step, 10, 0.3f, deltaTime);
    }
}


void Tema1::OnKeyPress(int key, int mods) {
    if (key == GLFW_KEY_SPACE) {
        tank1->LaunchProjectile(70);
    }

    if (key == GLFW_KEY_ENTER) {
        tank2->LaunchProjectile(70);
    }

    if (key == GLFW_KEY_R) {
        tank1->respawn(100, 428);
    }

    if (key == GLFW_KEY_RIGHT_CONTROL) {
        tank2->respawn(1142, 302);
    }

    if (key == GLFW_KEY_C) {
        float step = static_cast<float>(width) / (float) (heightMap.size() - 1);
        UpdateTerrainMesh(heightMap, step, terrainMesh);
        tank1->respawn(100, 428);
        tank2->respawn(1142, 302);
    }
}

void Tema1::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY) {
    //move turret angle
    if (mouseX > 0 && mouseX < width && mouseY > 0 && mouseY < height) {
        auto x = (float) mouseX;
        auto y = (float) (height - mouseY);
        float angle = atan2(y - tank1->getYPos(), x - tank1->getXPos());
        if (angle > -M_PI / 2 && angle < M_PI / 2)
            tank1->setTurretAngle(angle);
    }
}


void Tema1::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods) {
    if (IS_BIT_SET(button, GLFW_MOUSE_BUTTON_LEFT)) {
        tank1->LaunchProjectile(70);
    }
}

void Tema1::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY) {
    // scroll up - move to left scroll down move to right
    if (offsetY > 0) {
        if (tank1->getXPos() > 3) {
            tank1->setXPos(tank1->getXPos() - 5);
        }
    } else {
        if (tank1->getXPos() + 1 < (float) width - 10) {
            tank1->setXPos(tank1->getXPos() + 5);
        }
    }
}