#pragma once

#include "components/simple_scene.h"
#include <vector>
#include <iostream>
#include "lab_m1/lab3/transform2D.h"
#include "lab_m1/lab3/object2D.h"

namespace tema1 {
    class Projectile {
    public:
        glm::vec3 position, velocity;
        bool isActive;
    };

    class Tank {
    private:
        float x, y, bodyAngle, turretAngle;
        float baseWidth, topWidth, height;
        Mesh *bodyMesh, *turretMesh, *projMesh, *trajMesh, *HealthBarInt, *HealthBarExt;
        glm::vec3 turretPosition{};
        glm::vector<glm::vec3> trajectory;
        glm::vector<Projectile> projectiles;
        float lifePoints;
        Mesh *explosionMesh;
        float explX, explY;
    public:
        Tank(float x, float y, float baseWidth, float topWidth, float height,
             float initAngle);

        void hit();

        float getXPos() const;

        float getYPos() const;

        float getTurretAngle() const;

        float getBaseWidth() const;

        float getBodyAngle() const;

        Mesh *getBodyMesh() const;

        Mesh *getTurretMesh() const;

        Mesh *getTrajMesh() const;

        Mesh *getHealthIntMesh() const;

        Mesh *getHealthExtMesh() const;

        void setXPos(float x);

        void setYPos(float y);

        void setTurretAngle(float angleNew);

        void GenerateBody(glm::vec3 colorRails, glm::vec3 colorBody) const;

        void GenerateTurret(glm::vec3 color) const;

        void GenerateProjectile() const;

        void GenerateHealthBarInt() const;

        void GenerateHealthBarExt() const;

        void CreateTrajectory(float initialSpeed);

        void GenerateTrajectory();

        glm::mat3 RenderHealthBar() const;

        glm::mat3 RenderTank(const glm::vector<float> &heightMap, float step);

        glm::mat3 RenderTurret();

        void LaunchProjectile(float speed);

        void UpdateProjectiles(float deltaTime);

        static glm::mat3 RenderProjectile(Projectile &proj);

        glm::mat3 RenderTrajectory();

        glm::vector<Projectile> getProj();

        Mesh *getProjMesh() const;

        float getLifePoints() const;

        void respawn(float newX, float newY);

        void DeleteProjectile(int idx);

        Mesh *getExplosionMesh() const;

        glm::mat3 RenderExplosion(float deltaTime);

        void GenerateExplosion();
    };

    class Tema1 : public gfxc::SimpleScene {
    public:
        void Init() override;

        int height, width;
        Tank *tank1, *tank2;
        Mesh *terrainMesh;
        glm::vector<float> heightMap;

    private:
        void FrameStart() override;

        void Update(float deltaTimeSeconds) override;

        void FrameEnd() override;

        void OnInputUpdate(float deltaTime, int mods) override;

        void OnKeyPress(int key, int mods) override;

        void
        OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY) override;

        void
        OnMouseBtnPress(int mouseX, int mouseY, int button, int mods) override;

        void OnMouseScroll(int mouseX, int mouseY, int offsetX,
                           int offsetY) override;

    protected:
        glm::mat3 modelMatrix;

        void SimulateTerrainSliding(float step, float threshold, float friction,
                                    float deltaTime);

        void RenderProjectiles(Tank *currentTank, Tank *targetTank, float step);
    };

    // Functions and Variables for all the namespace
    void CreateMesh(Mesh *targetMesh, const std::vector<VertexFormat> &vertices,
                    const std::vector<unsigned int> &indices);

    Mesh *generateMesh(glm::vector<float> &heightMap, int height,
                       int width);

    bool
    CheckCollision(Tank *tank, Projectile &proj, glm::vector<float> &heightMap,
                   float terrainStep, Mesh *mesh);

    void
    UpdateTerrainMesh(const glm::vector<float> &heightMap, float terrainStep,
                      Mesh *mesh);

    void
    CreateCrater(glm::vector<float> &heightMap, int impactIndex, float impactY,
                 float terrainStep, Mesh *mesh);
}
