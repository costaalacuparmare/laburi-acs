#include <stdio.h>
#include <stdlib.h>

#include "dns.h"

#define HACKED_BIT_INDEX 7
#define KEY 0xBADB17C8

// TODO: freestyle starts here, implement Task 2
void task2(void *entries, int size, int target_ip) {

}
