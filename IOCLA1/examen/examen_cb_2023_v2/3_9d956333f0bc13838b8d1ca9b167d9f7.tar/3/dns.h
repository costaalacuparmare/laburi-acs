#pragma once

struct dns_entry {
    unsigned int ip;
    char hostname[24];
};
