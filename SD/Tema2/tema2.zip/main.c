#include "quadtree.h"

int main(int argc, char const *argv[]) {

	FILE *input = openIn(argv);
	FILE *output = openOut(argv);

	unsigned int size = 0;
	TPixel **grid = readPPM(grid, &size, input);

	int factor = atoi(argv[2]);
	TQuad qtree = buildQT(grid, size, 0, 0, factor);

	getTask(argv, qtree, output, size);

	Free(&qtree, grid, input, output, size);

	return 0;
}