#include "lista.h"

int main(){
    int lg = 0;
    TLista L = NULL;

    L = CitireLista(&lg);
    //printf("Dimensiune lista: %d\n", lg);
    int dim = 0;

    /* comanda pentru exercitiul 1 de mutare */
    AfisareLista(L2Ex1(&L,5,&dim));

    /* comanda pentru exercitiul 2 de copiere
    AfisareLista(L2Ex2(L,5,10,&dim));
    printf("%d\n",dim);
     */

    //DistrugeLista(&L);
    return 0;
}