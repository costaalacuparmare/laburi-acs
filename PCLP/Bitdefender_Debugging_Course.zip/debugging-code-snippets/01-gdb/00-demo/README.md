# 00-demo.c

## bugfix
* compile:
```bash
$ gcc 00-demo.c -o gigel
```

* run
```bash
$ ./gigel < input/numbers 
Segmentation fault (core dumped)

$ echo $?
139
```

* verify with gdb
```bash
o$ gdb ./gigel
...
(No debugging symbols found in ./gigel)

(gdb) r 
Starting program: 01-debugging/01-gdb/00-demo/gigel 
[Thread debugging using libthread_db enabled]
Using host libthread_db library "/lib/x86_64-linux-gnu/libthread_db.so.1".
2
1 2 

Program received signal SIGSEGV, Segmentation fault.
0x0000555555555243 in fun ()

(gdb) r < input/numbers 
The program being debugged has been started already.
Start it from the beginning? (y or n) y
Starting program: 01-debugging/01-gdb/00-demo/gigel < input/numbers
[Thread debugging using libthread_db enabled]
Using host libthread_db library "/lib/x86_64-linux-gnu/libthread_db.so.1".

Program received signal SIGSEGV, Segmentation fault.
0x0000555555555243 in fun ()

(gdb) bt
#0  0x0000555555555243 in fun ()
#1  0x00005555555552ae in main ()
(gdb) p n
No symbol "n" in current context.

(gdb) p v
No symbol "v" in current context.
```

*  missing debug symbols, recompile with `-g`
```bash
$ gcc -g  00-demo.c -o gigel
```

* recheck gdb run
```bash
$ gdb ./gigel
...
Reading symbols from ./gigel...
(gdb) r < input/numbers 
Starting program: 01-debugging/01-gdb/00-demo/gigel < input/numbers
[Thread debugging using libthread_db enabled]
Using host libthread_db library "/lib/x86_64-linux-gnu/libthread_db.so.1".

Program received signal SIGSEGV, Segmentation fault.
0x0000555555555243 in fun (n=5, v=0x5) at 00-demo.c:18
18	       sum += v[i];

(gdb) bt
#0  0x0000555555555243 in fun (n=5, v=0x5) at 00-demo.c:18
#1  0x00005555555552ae in main () at 00-demo.c:30

(gdb) p n
$1 = 5

(gdb) p v
$2 = (int *) 0x5

(gdb) p i
$ = 0

(gdb) p v[i]
Cannot access memory at address 0x5
```

* bugfix: return value in alloc_read_array

* recompile, rerun with gdb
```bash
$ git diff 00-demo.c
diff --git a/courses/01-debugging/01-gdb/00-demo/00-demo.c b/courses/01-debugging/01-gdb/00-demo/00-demo.c
index 1dcc5e4..6db082e 100644
--- a/courses/01-debugging/01-gdb/00-demo/00-demo.c
+++ b/courses/01-debugging/01-gdb/00-demo/00-demo.c
@@ -8,6 +8,8 @@ int *alloc_read_array(int n)
     for (int i = 0; i < n; ++i) {
         scanf("%d", &v[i]);
     }
+
+    return v;
 }
 
 int fun(int n, int *v)

$ gcc -g  00-demo.c -o gigel


$ ./gigel < input/numbers 
sum = 150

$ echo $?
0
```

## more gdb introspection
```bash
$ gdb ./gigel
...
Reading symbols from ./gigel...

# set breakpoints - first line in each function
(gdb) b main
Breakpoint 1 at 0x1268: file 00-demo.c, line 27.
(gdb) b alloc_read_array 
Breakpoint 2 at 0x11b8: file 00-demo.c, line 6.
(gdb) b fun
Breakpoint 3 at 0x1222: file 00-demo.c, line 17.

# run the program
(gdb) r < input/numbers 
Starting program: 01-debugging/01-gdb/00-demo/gigel < input/numbers
[Thread debugging using libthread_db enabled]
Using host libthread_db library "/lib/x86_64-linux-gnu/libthread_db.so.1".

Breakpoint 1, main () at 00-demo.c:27
27	{
# stop at breakpoint #1
# in main() - "before the program start"
(gdb) bt
#0  main () at 00-demo.c:27
# let the execution continue until next breakpoint

(gdb) c
Continuing.
Breakpoint 2, alloc_read_array (n=5) at 00-demo.c:6
6	    int *v = (int *) malloc(n * sizeof(int));
(gdb) bt
#0  alloc_read_array (n=5) at 00-demo.c:6
#1  0x000055555555529c in main () at 00-demo.c:31

# paramaters can be seen in previous log
# but we can also print them
(gdb) p n
$1 = 5
(gdb) p v
$2 = (int *) 0x0 # before the malloc line
(gdb) n
8	    for (int i = 0; i < n; ++i) {
(gdb) p v
$3 = (int *) 0x55555555a2b0 # after the malloc line

(gdb) c
Continuing.
Breakpoint 3, fun (n=5, v=0x55555555a2b0) at 00-demo.c:17
17	   int sum = 0;

(gdb) bt
#0  fun (n=5, v=0x55555555a2b0) at 00-demo.c:17
#1  0x00005555555552b1 in main () at 00-demo.c:32

# print variables
(gdb) p n
$4 = 5
(gdb) p v
$5 = (int *) 0x55555555a2b0
(gdb) p v[0]
$6 = 10
(gdb) p v[1]
$7 = 20
(gdb) p v[2]
$8 = 30
(gdb) p v[3]
$9 = 40
(gdb) p v[4]
$10 = 50

(gdb) c
Continuing.
sum = 150 # program finished
[Inferior 1 (process 24802) exited normally]
```