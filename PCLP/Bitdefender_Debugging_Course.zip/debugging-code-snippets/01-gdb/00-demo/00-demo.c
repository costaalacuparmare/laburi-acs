#include <stdio.h>
#include <stdlib.h>

int *alloc_read_array(int n)
{
    int *v = (int *) malloc(n * sizeof(int));

    for (int i = 0; i < n; ++i) {
        scanf("%d", &v[i]);
    }
}

int fun(int n, int *v)
{
    int sum = 0;

    for (int i = 0; i < n; ++i) {
       sum += v[i];
    } 

    return sum;
}

int main(void)
{
    int n;
    scanf("%d", &n);

    int *v = alloc_read_array(n);
    printf("sum = %d\n", fun(n, v));

    return 0;
}

