```bash
$ gcc -g 01-demo.c -o gigel
$ ./gigel 
Segmentation fault (core dumped)
$ gdb ./gigel 
GNU gdb (Ubuntu 11.1-0ubuntu2) 11.1
Copyright (C) 2021 Free Software Foundation, Inc.
License GPLv3+: GNU GPL version 3 or later <http://gnu.org/licenses/gpl.html>
This is free software: you are free to change and redistribute it.
There is NO WARRANTY, to the extent permitted by law.
Type "show copying" and "show warranty" for details.
This GDB was configured as "x86_64-linux-gnu".
Type "show configuration" for configuration details.
For bug reporting instructions, please see:
<https://www.gnu.org/software/gdb/bugs/>.
Find the GDB manual and other documentation resources online at:
    <http://www.gnu.org/software/gdb/documentation/>.

For help, type "help".
Type "apropos word" to search for commands related to "word"...
Reading symbols from ./gigel...
(gdb) start
Temporary breakpoint 1 at 0x11b5: file 01-demo.c, line 4.
Starting program: /home/dn/Desktop/baliza/courses/01-debugging/01-gdb/01-demo.c/gigel 
[Thread debugging using libthread_db enabled]
Using host libthread_db library "/lib/x86_64-linux-gnu/libthread_db.so.1".

Temporary breakpoint 1, main () at 01-demo.c:4
4	{
(gdb) n
5	    FILE *f = fopen("gigel.out", "r");
(gdb) n
8	    while (fscanf(f, "%d", &n) == 1) {
(gdb) p f
$1 = (FILE *) 0x0
(gdb)
```

* bugfix
```bash
n@pc:~/Desktop/baliza/courses/01-debugging/01-gdb/01-demo.c$ git diff 01-demo.c
diff --git a/courses/01-debugging/01-gdb/01-demo.c/01-demo.c b/courses/01-debugging/01-gdb/01-demo.c/01-demo.c
index 9ad2bbd..4c1fc2d 100644
--- a/courses/01-debugging/01-gdb/01-demo.c/01-demo.c
+++ b/courses/01-debugging/01-gdb/01-demo.c/01-demo.c
@@ -3,7 +3,11 @@
 int main(void)
 {
     FILE *f = fopen("gigel.out", "r");
-    
+    if (!f) {
+        // error;
+        return -1;
+    }
+
     int n;
     while (fscanf(f, "%d", &n) == 1) {
         printf("%d\n", n);
$ gcc -g 01-demo.c -o gigel
$ ./gigel 
$ echo $?
255

```