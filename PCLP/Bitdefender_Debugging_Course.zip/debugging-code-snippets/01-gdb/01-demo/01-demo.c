#include <stdio.h>

int main(void)
{
    FILE *f = fopen("gigel.out", "r");
    
    int n;
    while (fscanf(f, "%d", &n) == 1) {
        printf("%d\n", n);
    }

    return 0;
}
