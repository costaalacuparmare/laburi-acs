#include <stdio.h>

int main(void)
{
    FILE *f = fopen("in", "r");
    
    int n;
    while (fscanf(f, "%d", &n) == 1) {
        printf("%d\n", n);
    }

    return 0;
}
