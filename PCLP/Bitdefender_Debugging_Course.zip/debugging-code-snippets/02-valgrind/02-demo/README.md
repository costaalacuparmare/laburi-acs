* run with valgrind
```bash
$ gcc -g 02-demo.c -o gigel

$ valgrind --leak-check=full --show-leak-kinds=all --track-fds=yes --show-reachable=no ./gigel 
==35140== Memcheck, a memory error detector
==35140== Copyright (C) 2002-2017, and GNU GPL'd, by Julian Seward et al.
==35140== Using Valgrind-3.17.0 and LibVEX; rerun with -h for copyright info
==35140== Command: ./gigel
==35140== 
10
20
30
==35140== 
==35140== FILE DESCRIPTORS: 4 open (3 std) at exit.
==35140== Open file descriptor 3: in
==35140==    at 0x497C66B: open (open64.c:48)
==35140==    by 0x48F5045: _IO_file_open (fileops.c:189)
==35140==    by 0x48F53A1: _IO_file_fopen@@GLIBC_2.2.5 (fileops.c:281)
==35140==    by 0x48E873D: __fopen_internal (iofopen.c:75)
==35140==    by 0x48E873D: fopen@@GLIBC_2.2.5 (iofopen.c:86)
==35140==    by 0x1091DC: main (02-demo.c:5)
==35140== 
==35140== 
==35140== HEAP SUMMARY:
==35140==     in use at exit: 472 bytes in 1 blocks
==35140==   total heap usage: 3 allocs, 2 frees, 5,592 bytes allocated
==35140== 
==35140== LEAK SUMMARY:
==35140==    definitely lost: 0 bytes in 0 blocks
==35140==    indirectly lost: 0 bytes in 0 blocks
==35140==      possibly lost: 0 bytes in 0 blocks
==35140==    still reachable: 472 bytes in 1 blocks
==35140==         suppressed: 0 bytes in 0 blocks
==35140== Reachable blocks (those to which a pointer was found) are not shown.
==35140== To see them, rerun with: --leak-check=full --show-leak-kinds=all
==35140== 
==35140== For lists of detected and suppressed errors, rerun with: -s
==35140== ERROR SUMMARY: 0 errors from 0 contexts (suppressed: 0 from 0)
```

* bugfix
```bash
$ git diff 02-demo.c
diff --git a/courses/01-debugging/02-valgrind/02-demo/02-demo.c b/courses/01-debugging/02-valgrind/02-demo/02-demo.c
index 820d020..6a435de 100644
--- a/courses/01-debugging/02-valgrind/02-demo/02-demo.c
+++ b/courses/01-debugging/02-valgrind/02-demo/02-demo.c
@@ -9,5 +9,7 @@ int main(void)
         printf("%d\n", n);
     }
 
+    fclose(f);
+
     return 0;
 }
```