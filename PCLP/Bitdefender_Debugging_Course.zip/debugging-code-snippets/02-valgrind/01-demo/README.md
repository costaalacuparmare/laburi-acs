* compile
```bash
$ gcc -g 01-demo.c -o demo
```

* run
```
$ gcc -g 01-demo.c -o gigel
$ ./gigel 
5
sum = 23

$ gcc -g 01-demo.c -o gigel
$ ./gigel 
3
sum = 16

$ ./gigel 
5
sum = 23

$ valgrind --track-origins=yes ./gigel 
==34577== Memcheck, a memory error detector
==34577== Copyright (C) 2002-2017, and GNU GPL'd, by Julian Seward et al.
==34577== Using Valgrind-3.17.0 and LibVEX; rerun with -h for copyright info
==34577== Command: ./gigel
==34577== 
3
==34577== Conditional jump or move depends on uninitialised value(s)
==34577==    at 0x48DEC86: __vfprintf_internal (vfprintf-internal.c:1646)
==34577==    by 0x48C956E: printf (printf.c:33)
==34577==    by 0x1091F2: main (01-demo.c:14)
==34577==  Uninitialised value was created by a stack allocation
==34577==    at 0x109189: main (01-demo.c:5)
==34577== 
==34577== Use of uninitialised value of size 8
==34577==    at 0x48C314B: _itoa_word (_itoa.c:179)
==34577==    by 0x48DE944: __vfprintf_internal (vfprintf-internal.c:1646)
==34577==    by 0x48C956E: printf (printf.c:33)
==34577==    by 0x1091F2: main (01-demo.c:14)
==34577==  Uninitialised value was created by a stack allocation
==34577==    at 0x109189: main (01-demo.c:5)
==34577== 
==34577== Conditional jump or move depends on uninitialised value(s)
==34577==    at 0x48C315C: _itoa_word (_itoa.c:179)
==34577==    by 0x48DE944: __vfprintf_internal (vfprintf-internal.c:1646)
==34577==    by 0x48C956E: printf (printf.c:33)
==34577==    by 0x1091F2: main (01-demo.c:14)
==34577==  Uninitialised value was created by a stack allocation
==34577==    at 0x109189: main (01-demo.c:5)
==34577== 
==34577== Conditional jump or move depends on uninitialised value(s)
==34577==    at 0x48DF5C3: __vfprintf_internal (vfprintf-internal.c:1646)
==34577==    by 0x48C956E: printf (printf.c:33)
==34577==    by 0x1091F2: main (01-demo.c:14)
==34577==  Uninitialised value was created by a stack allocation
==34577==    at 0x109189: main (01-demo.c:5)
==34577== 
==34577== Conditional jump or move depends on uninitialised value(s)
==34577==    at 0x48DEA67: __vfprintf_internal (vfprintf-internal.c:1646)
==34577==    by 0x48C956E: printf (printf.c:33)
==34577==    by 0x1091F2: main (01-demo.c:14)
==34577==  Uninitialised value was created by a stack allocation
==34577==    at 0x109189: main (01-demo.c:5)
==34577== 
sum = 16
==34577== 
==34577== HEAP SUMMARY:
==34577==     in use at exit: 0 bytes in 0 blocks
==34577==   total heap usage: 2 allocs, 2 frees, 2,048 bytes allocated
==34577== 
==34577== All heap blocks were freed -- no leaks are possible
==34577== 
==34577== For lists of detected and suppressed errors, rerun with: -s
==34577== ERROR SUMMARY: 7 errors from 5 contexts (suppressed: 0 from 0)
```

* bugfix: initialize sum = 0