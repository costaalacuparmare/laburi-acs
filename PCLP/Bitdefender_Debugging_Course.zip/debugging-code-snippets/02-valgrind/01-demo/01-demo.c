#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int n;
    scanf("%d", &n);

    int sum;
    for (int i = 0; i < n; ++i) {
        sum += i;
    }

    printf("sum = %d\n", sum);

    return 0;
}
