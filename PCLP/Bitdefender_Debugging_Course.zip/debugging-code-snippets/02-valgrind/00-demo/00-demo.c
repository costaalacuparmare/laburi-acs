#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int n;
    scanf("%d", &n);

    int* v = malloc(n * sizeof(int));
    return 0;
}
