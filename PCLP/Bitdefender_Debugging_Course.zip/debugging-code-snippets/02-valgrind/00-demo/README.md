* compile
```bash
$ gcc -g 00-demo.c -o gigel
```

* run
```bash
$ ./gigel 
10
```

* seem to be OK

* run with valgrind
```bash
$ valgrind --leak-check=full --show-leak-kinds=all --track-fds=yes --show-reachable=no ./gigel 
==33633== Memcheck, a memory error detector
==33633== Copyright (C) 2002-2017, and GNU GPL'd, by Julian Seward et al.
==33633== Using Valgrind-3.17.0 and LibVEX; rerun with -h for copyright info
==33633== Command: ./gigel
==33633== 
10
==33633== 
==33633== FILE DESCRIPTORS: 3 open (3 std) at exit.
==33633== 
==33633== HEAP SUMMARY:
==33633==     in use at exit: 40 bytes in 1 blocks
==33633==   total heap usage: 2 allocs, 1 frees, 1,064 bytes allocated
==33633== 
==33633== 40 bytes in 1 blocks are definitely lost in loss record 1 of 1
==33633==    at 0x4843839: malloc (in /usr/libexec/valgrind/vgpreload_memcheck-amd64-linux.so)
==33633==    by 0x1091CF: main (00-demo.c:9)
==33633== 
==33633== LEAK SUMMARY:
==33633==    definitely lost: 40 bytes in 1 blocks
==33633==    indirectly lost: 0 bytes in 0 blocks
==33633==      possibly lost: 0 bytes in 0 blocks
==33633==    still reachable: 0 bytes in 0 blocks
==33633==         suppressed: 0 bytes in 0 blocks
==33633== 
==33633== For lists of detected and suppressed errors, rerun with: -s
==33633== ERROR SUMMARY: 1 errors from 1 contexts (suppressed: 0 from 0)
```

* so memory leak -> bugfix add free call