# valgrind - 03.demo.c

* compile
```bash
$ gcc -g 03-democ.c -o gigel
```

* run
```bash
$ ./gigel 
2
1 2
2

12
1
21
21
21
21
21
2
12
11
21
```


* not stopping ...

* bugfix: missing i++
```bash
$ git diff 03-demo.c
diff --git a/courses/01-debugging/02-valgrind/03-demo/03-demo.c b/courses/01-debugging/02-valgrind/03-demo/03-demo.c
index 09685e5..d53723f 100644
--- a/courses/01-debugging/02-valgrind/03-demo/03-demo.c
+++ b/courses/01-debugging/02-valgrind/03-demo/03-demo.c
@@ -18,6 +18,7 @@ int fun(int n, int *v)
     int i = 0;
     do  {
         sum += v[i];
+        ++i;
     } while (i < n);
 
     return sum;
$ gcc -g 03-demo.c -o gigel
$ ./gigel 
2
1 2
sum = 3
```


* what other input show we test?

* run with n = -1
```bash
$ ./gigel 
-1
Segmentation fault (core dumped)
```

* run with valgrind and with gdb
```bash
$ valgrind ./gigel 
==32483== Memcheck, a memory error detector
==32483== Copyright (C) 2002-2017, and GNU GPL'd, by Julian Seward et al.
==32483== Using Valgrind-3.17.0 and LibVEX; rerun with -h for copyright info
==32483== Command: ./gigel
==32483== 
-1
==32483== Argument 'size' of function malloc has a fishy (possibly negative) value: -4
==32483==    at 0x4843839: malloc (in /usr/libexec/valgrind/vgpreload_memcheck-amd64-linux.so)
==32483==    by 0x1091E8: alloc_read_array (03-demo.c:6)
==32483==    by 0x1092B9: main (03-demo.c:32)
==32483== 
==32483== Invalid read of size 4
==32483==    at 0x109264: fun (03-demo.c:20)
==32483==    by 0x1092CE: main (03-demo.c:33)
==32483==  Address 0x0 is not stack'd, malloc'd or (recently) free'd
==32483== 
==32483== 
==32483== Process terminating with default action of signal 11 (SIGSEGV)
==32483==  Access not within mapped region at address 0x0
==32483==    at 0x109264: fun (03-demo.c:20)
==32483==    by 0x1092CE: main (03-demo.c:33)
==32483==  If you believe this happened as a result of a stack
==32483==  overflow in your program's main thread (unlikely but
==32483==  possible), you can try to increase the size of the
==32483==  main thread stack using the --main-stacksize= flag.
==32483==  The main thread stack size used in this run was 8388608.
==32483== 
==32483== HEAP SUMMARY:
==32483==     in use at exit: 0 bytes in 0 blocks
==32483==   total heap usage: 1 allocs, 1 frees, 1,024 bytes allocated
==32483== 
==32483== All heap blocks were freed -- no leaks are possible
==32483== 
==32483== For lists of detected and suppressed errors, rerun with: -s
==32483== ERROR SUMMARY: 2 errors from 2 contexts (suppressed: 0 from 0)
Segmentation fault (core dumped)

$ gdb ./gigel 
...
Reading symbols from ./gigel...
(gdb) r
Starting program: 01-debugging/02-valgrind/03-demo/gigel 
[Thread debugging using libthread_db enabled]
Using host libthread_db library "/lib/x86_64-linux-gnu/libthread_db.so.1".
-1

Program received signal SIGSEGV, Segmentation fault.
0x0000555555555264 in fun (n=-1, v=0x0) at 03-demo.c:20
20	        sum += v[i];
(gdb) p v
$1 = (int *) 0x0
```

* bugfix
```bash
$ git diff 03-demo.c
diff --git a/courses/01-debugging/02-valgrind/03-demo/03-demo.c b/courses/01-debugging/02-valgrind/03-demo/03-demo.c
index 09685e5..8d60289 100644
--- a/courses/01-debugging/02-valgrind/03-demo/03-demo.c
+++ b/courses/01-debugging/02-valgrind/03-demo/03-demo.c
@@ -18,6 +18,7 @@ int fun(int n, int *v)
     int i = 0;
     do  {
         sum += v[i];
+        ++i;
     } while (i < n);
 
     return sum;
@@ -28,6 +29,11 @@ int main(void)
     int n;
     scanf("%d", &n);
 
+    if (n < 0) {
+        fprintf(stderr, "Invalid value: n = %d\n", n);
+        return -1;
+    }
+
     int *v = alloc_read_array(n);
     printf("sum = %d\n", fun(n, v));
     free(v);

$ gcc -g 03-demo.c -o gigel

$ ./gigel 
-1
Invalid value: n = -1
```