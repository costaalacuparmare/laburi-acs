// nu reusesc sa rezolv acest exercitiu
#include <stdio.h>
#include <math.h>

int main () {
    int a = 3, b = 4, c = 5, u = -100, v = 100;
    int delta = b * b - 4 * a * c;
    printf("%d", delta);
    double x1 = (-b + sqrt(delta)) / (2*a);
    double x2 = (-b - sqrt(delta)) / (2*a);
    printf("radacinile din intervalul [%d,%d] sunt %f, %f.", u, v, x1, x2);
    return 0;
} 
