import java.util.ArrayList;

public class SetCover {

    public static int setCover(int[] universe, ArrayList<Integer>[] subsets) {
		// ----- Intoarce 1 daca e adevarat si 0 daca e false ------
		// ----- TO DO : Verifica daca toate elementele din univers sunt in cel putin un subset ------
		

		return 1; // modify return value
    }
}
