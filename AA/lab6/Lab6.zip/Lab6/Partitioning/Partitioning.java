public class Partitioning {

    public static int partitioning(int[] subSet1, int[] subSet2) {
		// ----- Intoarce 1 daca e adevarat si 0 daca e false ------

		// ----- Verificare daca suma elementelor din subSet1 este egala cu suma elementelor din subSet2 ------


		return 0; // modify return value
    }
}
