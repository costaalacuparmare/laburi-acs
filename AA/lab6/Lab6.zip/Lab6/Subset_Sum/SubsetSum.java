public class SubsetSum {

    public static int subsetSum(int[] subSet, long K) {
		// ----- Intoarce 1 daca e adevarat si 0 daca e false ------

		// ----- Verificare daca suma elementelor din subSet este egala cu K ------

		return 0; // modify return value
    }
}
