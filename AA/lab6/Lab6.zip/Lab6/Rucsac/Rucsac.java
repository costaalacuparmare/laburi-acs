public class Rucsac {

    public static int rucsac(int[] valori, int[] greutati, int capacitate) {
		int n = valori.length;
		int[][] dp = new int[n+1][capacitate+1];

		//TO DO STUDENT

		return 0; // Modify return value
    }
}
